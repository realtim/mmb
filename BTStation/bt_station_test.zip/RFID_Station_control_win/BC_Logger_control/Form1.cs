﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;


namespace BC_Logger_control
{
    public partial class Form1 : Form
    {
        private const int inputCodePage = 866;

        public static System.Timers.Timer aTimer;
        private bool packetReady = false;
        private long timeout = 500;

        private class chipData
        {
            public byte pageNumber;
            public byte[] pageData = new byte[4];
        };

        private class teamData
        {
            public uint teamNumber;
            public uint teamMask;
            public DateTime checkInTime;
        };

        //команды
        private static class Command
        {
            public static byte SET_MODE = 0x80;
            public static byte SET_TIME = 0x81;
            public static byte RESET_STATION = 0x82;
            public static byte GET_STATUS = 0x83;
            public static byte INIT_CHIP = 0x84;
            public static byte GET_LAST_TEAM = 0x85;
            public static byte GET_CHIP_HISTORY = 0x86;
            public static byte READ_CARD_PAGE = 0x87;
            public static byte UPDATE_TEAM_MASK = 0x88;
            public static byte WRITE_CARD_PAGE = 0x89;
            public static byte READ_FLASH = 0x8a;
            public static byte WRITE_FLASH = 0x8b;
        }
        //размеры данных для команд header[6]+crc[1]+data[?]
        private static class CommandDataLength
        {
            public const byte SET_MODE = 6 + 1 + 1;
            public const byte SET_TIME = 6 + 1 + 6;
            public const byte RESET_STATION = 6 + 1 + 7;
            public const byte GET_STATUS = 6 + 1;
            public const byte INIT_CHIP = 6 + 1 + 4;
            public const byte GET_LAST_TEAM = 6 + 1;
            public const byte GET_CHIP_HISTORY = 6 + 1 + 2;
            public const byte READ_CARD_PAGE = 6 + 1 + 2;
            public const byte UPDATE_TEAM_MASK = 6 + 1 + 8;
            public const byte WRITE_CARD_PAGE = 6 + 1 + 13;
            public const byte READ_FLASH = 6 + 1 + 8;
            public const byte WRITE_FLASH = 6 + 1 + 4;
        }

        //ответы станции
        private static class Reply
        {
            public const byte SET_MODE = 0x90;
            public const byte SET_TIME = 0x91;
            public const byte RESET_STATION = 0x92;
            public const byte GET_STATUS = 0x93;
            public const byte INIT_CHIP = 0x94;
            public const byte GET_LAST_TEAM = 0x95;
            public const byte GET_CHIP_HISTORY = 0x96;
            public const byte READ_CARD_PAGE = 0x97;
            public const byte UPDATE_TEAM_MASK = 0x98;
            public const byte WRITE_CARD_PAGE = 0x99;
            public const byte READ_FLASH = 0x9a;
            public const byte WRITE_FLASH = 0x9b;
        }
        //размеры данных для ответов
        private static class ReplyDataLength
        {
            public static byte SET_MODE = 1;
            public static byte SET_TIME = 5;
            public static byte RESET_STATION = 7;
            public static byte GET_STATUS = 17;
            public static byte INIT_CHIP = 13;
            public static byte GET_LAST_TEAM = 13;
            public static byte GET_CHIP_HISTORY = 13;
            public static byte READ_CARD_PAGE = 1;
            public static byte UPDATE_TEAM_MASK = 1;
            public static byte WRITE_CARD_PAGE = 1;
            public const byte READ_FLASH = 1;
            public const byte WRITE_FLASH = 2;
        }

        private string[] ReplyStrings = new string[]
        {
            "SET_MODE",
            "SET_TIME",
            "RESET_STATION",
            "GET_STATUS",
            "INIT_CHIP",
            "GET_LAST_TEAM",
            "GET_CHIP_HISTORY",
            "READ_CARD_PAGE",
            "UPDATE_TEAM_MASK",
            "WRITE_CARD_PAGE",
            "READ_FLASH",
            "WRITE_FLASH"
        };

        //режимы станции
        private string[] StationModeStrings = new string[]
        {
            "INIT",
            "START_KP",
            "FINISH_KP"
        };

        //коды ошибок станции
        private string[] errorCodesStrings = new string[]
        {
            "OK",
            "WRONG_STATION",
            "READ_ERROR",
            "WRITE_ERROR",
            "LOW_INIT_TIME",
            "WRONG_CHIP",
            "NO_CHIP",
            "BUFFER_OVERFLOW",
            "WRONG_DATA",
            "WRONG_UID",
            "WRONG_TEAM",
            "NO_DATA",
        };

        //header 0xFE [0-2] + station#[3] + len[4] + cmd#[5] + data[6]... + crc
        private static class PacketBytes
        {
            public static byte STATION_NUMBER = 3;
            public static byte LENGTH = 4;
            public static byte COMMAND = 5;
            public static byte DATA_START = 6;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.Encoding = Encoding.GetEncoding(inputCodePage);
            //Serial init
            comboBox_portName.Items.Add("None");
            foreach (string portname in SerialPort.GetPortNames())
            {
                comboBox_portName.Items.Add(portname); //добавить порт в список
            }
            if (comboBox_portName.Items.Count == 1)
            {
                comboBox_portName.SelectedIndex = 0;
                button_openPort.Enabled = false;
            }
            else
            {
                comboBox_portName.SelectedIndex = 0;
            }
            textBox_setTime.Text = getDateToString(DateTime.Now);
            comboBox_mode.SelectedIndex = 0;
            comboBox_chipType.SelectedIndex = 1;
        }

        #region COM_ports
        private void button_refresh_Click(object sender, EventArgs e)
        {
            comboBox_portName.Items.Clear();
            comboBox_portName.Items.Add("None");
            foreach (string portname in SerialPort.GetPortNames())
            {
                comboBox_portName.Items.Add(portname); //добавить порт в список
            }
            if (comboBox_portName.Items.Count == 1)
            {
                comboBox_portName.SelectedIndex = 0;
                button_openPort.Enabled = false;
            }
            else
                comboBox_portName.SelectedIndex = 0;


            Hashtable PortNames = new Hashtable();
            string[] ports = System.IO.Ports.SerialPort.GetPortNames();
            if (ports.Length == 0)
            {
                textBox_terminal.Text += "ERROR: No COM ports exist\n\r";
            }
            else
            {
                PortNames = Accessory.BuildPortNameHash(ports);
                foreach (String s in PortNames.Keys)
                {
                    textBox_terminal.Text += "\n\r" + PortNames[s] + ": " + s + "\n\r";
                }
            }



        }

        private void button_openPort_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true) comboBox_portName.SelectedIndex=0;
            if (comboBox_portName.SelectedIndex != 0)
            {
                //comboBox_portname1.Enabled = false;
                serialPort1.PortName = comboBox_portName.Text;
                serialPort1.BaudRate = RFID_Station_control.Properties.Settings.Default.BaudRate;
                serialPort1.DataBits = 8;
                serialPort1.Parity = Parity.None;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Handshake = Handshake.None;
                serialPort1.ReadTimeout = 500;
                serialPort1.WriteTimeout = 500;
                try
                {
                    serialPort1.Open();
                }
                catch (Exception ex)
                {
                    SetText("Error opening port " + serialPort1.PortName + ": " + ex.Message);
                }
                //while (serialPort1.IsOpen == false) ;
                if (!serialPort1.IsOpen) return;

                button_getLastTeam.Enabled = true;
                button_getChipsHistory.Enabled = true;
                button_updTeamMask.Enabled = true;
                button_initChip.Enabled = true;
                button_readChipPage.Enabled = true;
                button_writeChipPage.Enabled = true;

                button_setMode.Enabled = true;
                button_resetStation.Enabled = true;
                button_setTime.Enabled = true;
                button_getStatus.Enabled = true;
                button_getStatus.Enabled = true;
                button_readFlash.Enabled = true;
                button_writeFlash.Enabled = true;

                button_closePort.Enabled = true;
                button_openPort.Enabled = false;
                button_refresh.Enabled = false;
                comboBox_portName.Enabled = false;
                //aTimer.Enabled = true;
            }
        }

        private void button_closePort_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception ex)
                {
                    SetText("Error closing port " + serialPort1.PortName + ": " + ex.Message);
                }
            }


            button_getLastTeam.Enabled = false;
            button_getChipsHistory.Enabled = false;
            button_updTeamMask.Enabled = false;
            button_initChip.Enabled = false;
            button_readChipPage.Enabled = false;
            button_writeChipPage.Enabled = false;

            button_setMode.Enabled = false;
            button_resetStation.Enabled = false;
            button_setTime.Enabled = false;
            button_getStatus.Enabled = false;
            button_getStatus.Enabled = false;
            button_readFlash.Enabled = false;
            button_writeFlash.Enabled = false;

            //aTimer.Enabled = false;
            button_closePort.Enabled = false;
            button_openPort.Enabled = true;
            button_refresh.Enabled = true;
            comboBox_portName.Enabled = true;
        }

        //rewrite to validate packet runtime
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            Accessory.Delay_ms(timeout);
            if (checkBox_portMon.Checked)
            {
                List<byte> rx = new List<byte>();
                while (serialPort1.BytesToRead > 0)
                {
                    rx.Add((byte)serialPort1.ReadByte());
                }
                SetText("<< " + Accessory.ConvertByteArrayToHex(rx.ToArray()) + "\r\n");
                string parseResult = parsePackage(rx.ToArray()) + "\r\n";
                SetText(parseResult + "\r\n");
            }
        }

        private void serialPort1_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            SetText("COM port error: " + e.ToString() + "\r\n");
        }

        private void sendCommand(byte[] command)
        {
            command[0] = 0xFE;
            command[1] = 0xFE;
            command[2] = 0xFE;
            command[PacketBytes.STATION_NUMBER] = byte.Parse(textBox_stationNumber.Text);
            command[PacketBytes.LENGTH] = (byte)(command.Length - PacketBytes.DATA_START - 1);
            command[command.Length - 1] = Accessory.crcCalc(command, PacketBytes.STATION_NUMBER, command.Length - 2);
            serialPort1.Write(command, 0, command.Length);
            SetText(">> "
                + Accessory.ConvertByteArrayToHex(command)
                + "\r\n");
        }
        #endregion

        #region Terminal_window
        private void textBox_terminal_TextChanged(object sender, EventArgs e)
        {
            if (checkBox_autoScroll.Checked == true)
            {
                textBox_terminal.SelectionStart = textBox_terminal.Text.Length;
                textBox_terminal.ScrollToCaret();
            }
        }
        private void button_clear_Click(object sender, EventArgs e)
        {
            textBox_terminal.Text = "";
        }

        private void button_saveFile_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            File.WriteAllText(saveFileDialog1.FileName, textBox_terminal.Text);
        }
        #endregion

        #region Generate commands
        private void button_setMode_Click(object sender, EventArgs e)
        {
            byte[] setMode = new byte[CommandDataLength.SET_MODE];
            setMode[PacketBytes.COMMAND] = Command.SET_MODE;

            //0: новый номер режима
            setMode[PacketBytes.DATA_START] = (byte)comboBox_mode.SelectedIndex;
            sendCommand(setMode);
        }

        private void button_setTime_Click(object sender, EventArgs e)
        {
            byte[] setTime = new byte[CommandDataLength.SET_TIME];
            setTime[PacketBytes.COMMAND] = Command.SET_TIME;

            //0-5: дата и время[yy.mm.dd hh: mm:ss]
            if (checkBox_autoTime.Checked)
                textBox_setTime.Text = getDateToString(DateTime.Now);
            byte[] date = DateStringToByteArray(textBox_setTime.Text);
            if (date.Length != 6)
                return;
            for (int i = 0; i < 6; i++)
                setTime[PacketBytes.DATA_START + i] = date[i];

            sendCommand(setTime);
        }

        private void button_resetStation_Click(object sender, EventArgs e)
        {
            byte[] resetStation = new byte[CommandDataLength.RESET_STATION];
            resetStation[PacketBytes.COMMAND] = Command.RESET_STATION;

            /*0-1: кол-во отмеченных карт (для сверки)
			2-5: время последней отметки unixtime(для сверки)
            6: новый номер станции*/
            uint chipsNumber = uint.Parse(textBox_checkedChips.Text);
            resetStation[PacketBytes.DATA_START + 0] = (byte)(chipsNumber >> 8);
            resetStation[PacketBytes.DATA_START + 1] = (byte)(chipsNumber & 0x00ff);

            long tmpTime = DateStringToUnixTime(textBox_lastCheck.Text);
            resetStation[PacketBytes.DATA_START + 2] = (byte)((tmpTime & 0xFF000000) >> 24);
            resetStation[PacketBytes.DATA_START + 3] = (byte)((tmpTime & 0x00FF0000) >> 16);
            resetStation[PacketBytes.DATA_START + 4] = (byte)((tmpTime & 0x0000FF00) >> 8);
            resetStation[PacketBytes.DATA_START + 5] = (byte)(tmpTime & 0x000000FF);

            resetStation[PacketBytes.DATA_START + 6] = byte.Parse(textBox_newStationNumber.Text);

            sendCommand(resetStation);
        }

        private void button_getStatus_Click(object sender, EventArgs e)
        {
            byte[] getStatus = new byte[CommandDataLength.GET_STATUS];
            getStatus[PacketBytes.COMMAND] = Command.GET_STATUS;

            sendCommand(getStatus);
        }

        private void button_initChip_Click(object sender, EventArgs e)
        {
            byte[] initChip = new byte[CommandDataLength.INIT_CHIP];
            initChip[PacketBytes.COMMAND] = Command.INIT_CHIP;

            /*0-1: номер команды
			2-3: маска участников*/
            uint cmd = uint.Parse(textBox_commandNumber.Text);
            initChip[PacketBytes.DATA_START] = (byte)(cmd >> 8);
            initChip[PacketBytes.DATA_START + 1] = (byte)cmd;

            uint mask = uint.Parse(textBox_teamMask.Text);
            initChip[PacketBytes.DATA_START + 2] = (byte)(mask >> 8);
            initChip[PacketBytes.DATA_START + 3] = (byte)(mask & 0x00ff);

            /*byte[] uid = Accessory.ConvertHexToByteArray(textBox_uidInit.Text);
            if (uid.Length != 8)
                return;
            for (int i = 0; i <= 7; i++)
                initChip[PacketBytes.DATA_START + i] = uid[i];*/

            sendCommand(initChip);
        }

        private void button_getLastTeam_Click(object sender, EventArgs e)
        {
            byte[] getLastTeam = new byte[CommandDataLength.GET_LAST_TEAM];
            getLastTeam[PacketBytes.COMMAND] = Command.GET_LAST_TEAM;

            sendCommand(getLastTeam);
        }

        private void button_getChipHistory_Click(object sender, EventArgs e)
        {
            byte[] getChipHistory = new byte[CommandDataLength.GET_CHIP_HISTORY];
            getChipHistory[PacketBytes.COMMAND] = Command.GET_CHIP_HISTORY;

            //0-1: какую запись
            uint from = uint.Parse(textBox_records.Text);
            getChipHistory[PacketBytes.DATA_START] = (byte)(from >> 8);
            getChipHistory[PacketBytes.DATA_START + 1] = (byte)(from & 0x00ff);

            sendCommand(getChipHistory);
        }

        private void button_readCardPage_Click(object sender, EventArgs e)
        {
            byte[] readCardPage = new byte[CommandDataLength.READ_CARD_PAGE];
            readCardPage[PacketBytes.COMMAND] = Command.READ_CARD_PAGE;

            //0: с какой страницу карты
            byte from = byte.Parse(textBox_readChipPage.Text.Substring(0, textBox_readChipPage.Text.IndexOf("-")).Trim());
            readCardPage[PacketBytes.DATA_START] = from;
            //1: по какую страницу карты включительно
            byte to = byte.Parse(textBox_readChipPage.Text.Substring(textBox_readChipPage.Text.IndexOf("-") + 1).Trim());
            readCardPage[PacketBytes.DATA_START + 1] = to;

            sendCommand(readCardPage);
        }

        private void button_updateTeamMask_Click(object sender, EventArgs e)
        {
            byte[] updateTeamMask = new byte[CommandDataLength.UPDATE_TEAM_MASK];
            updateTeamMask[PacketBytes.COMMAND] = Command.UPDATE_TEAM_MASK;

            /*0-1: номер команды
			2-5: время выдачи чипа
			6-7: маска участников*/
            uint cmd = uint.Parse(textBox_commandNumber.Text);
            updateTeamMask[PacketBytes.DATA_START] = (byte)(cmd >> 8);
            updateTeamMask[PacketBytes.DATA_START + 1] = (byte)cmd;

            //card issue time - 4 byte
            //textBox_issueTime.Text
            long tmpTime = DateStringToUnixTime(textBox_issueTime.Text);
            updateTeamMask[PacketBytes.DATA_START + 2] = (byte)((tmpTime & 0xFF000000) >> 24);
            updateTeamMask[PacketBytes.DATA_START + 3] = (byte)((tmpTime & 0x00FF0000) >> 16);
            updateTeamMask[PacketBytes.DATA_START + 4] = (byte)((tmpTime & 0x0000FF00) >> 8);
            updateTeamMask[PacketBytes.DATA_START + 5] = (byte)(tmpTime & 0x000000FF);


            uint mask = uint.Parse(textBox_teamMask.Text);
            updateTeamMask[PacketBytes.DATA_START + 6] = (byte)(mask >> 8);
            updateTeamMask[PacketBytes.DATA_START + 7] = (byte)(mask & 0x00ff);

            sendCommand(updateTeamMask);
        }

        private void button_writeCardPage_Click(object sender, EventArgs e)
        {
            byte[] writeCardPage = new byte[CommandDataLength.WRITE_CARD_PAGE];
            writeCardPage[PacketBytes.COMMAND] = Command.WRITE_CARD_PAGE;

            //0-7: UID чипа
            //8: номер страницы
            //9-12: данные из страницы карты (4 байта)
            byte[] uid = Accessory.ConvertHexToByteArray(textBox_uid.Text);
            if (uid.Length != 8)
                return;
            for (int i = 0; i <= 7; i++)
                writeCardPage[PacketBytes.DATA_START + i] = uid[i];

            writeCardPage[PacketBytes.DATA_START + 8] = byte.Parse(textBox_writeChipPage.Text);

            byte[] data = Accessory.ConvertHexToByteArray(textBox_data.Text);

            if (data.Length != 4)
                return;
            for (int i = 0; i <= 3; i++)
                writeCardPage[PacketBytes.DATA_START + 9 + i] = data[i];

            sendCommand(writeCardPage);
        }

        private void button_readFlash_Click(object sender, EventArgs e)
        {
            byte[] readFlash = new byte[CommandDataLength.READ_FLASH];
            readFlash[PacketBytes.COMMAND] = Command.READ_FLASH;

            //0-3: адрес начала чтения
            //4-7: адрес конца чтения

            string from = textBox_readFlash.Text.Substring(0, textBox_readFlash.Text.IndexOf("-")).Trim();
            string to = textBox_readFlash.Text.Substring(textBox_readFlash.Text.IndexOf("-") + 1).Trim();

            long fromAddr = long.Parse(from);
            readFlash[PacketBytes.DATA_START] = (byte)((fromAddr & 0xFF000000) >> 24);
            readFlash[PacketBytes.DATA_START + 1] = (byte)((fromAddr & 0x00FF0000) >> 16);
            readFlash[PacketBytes.DATA_START + 2] = (byte)((fromAddr & 0x0000FF00) >> 8);
            readFlash[PacketBytes.DATA_START + 3] = (byte)(fromAddr & 0x000000FF);

            long toAddr = long.Parse(to);
            readFlash[PacketBytes.DATA_START + 4] = (byte)((toAddr & 0xFF000000) >> 24);
            readFlash[PacketBytes.DATA_START + 5] = (byte)((toAddr & 0x00FF0000) >> 16);
            readFlash[PacketBytes.DATA_START + 6] = (byte)((toAddr & 0x0000FF00) >> 8);
            readFlash[PacketBytes.DATA_START + 7] = (byte)(toAddr & 0x000000FF);

            sendCommand(readFlash);
        }

        private void button_writeFlash_Click(object sender, EventArgs e)
        {
            byte[] data = Accessory.ConvertHexToByteArray(textBox_flashData.Text);

            byte[] writeFlash = new byte[CommandDataLength.WRITE_FLASH + data.Length];
            writeFlash[PacketBytes.COMMAND] = Command.WRITE_FLASH;

            //0-3: адрес начала записи
            //4...: данные для записи
            long tmpTime = long.Parse(textBox_writeAddr.Text);
            writeFlash[PacketBytes.DATA_START] = (byte)((tmpTime & 0xFF000000) >> 24);
            writeFlash[PacketBytes.DATA_START + 1] = (byte)((tmpTime & 0x00FF0000) >> 16);
            writeFlash[PacketBytes.DATA_START + 2] = (byte)((tmpTime & 0x0000FF00) >> 8);
            writeFlash[PacketBytes.DATA_START + 3] = (byte)(tmpTime & 0x000000FF);

            for (byte i = 0; i < data.Length; i++)
                writeFlash[PacketBytes.DATA_START + 4 + i] = data[i];

            sendCommand(writeFlash);
        }

        #endregion

        #region Parse replies
        private string parsePackage(byte[] data)
        {
            int i = 0;
            while (i < data.Length)
            {
                int c = data[i];
                //0 byte = FE
                if (i == 0 && c == 0xfe)
                {
                    i++;
                }
                //1st byte = FE
                else if (i == 1 && c == 0xfe)
                {
                    i++;
                }
                //2nd byte = FE
                else if (i == 2 && c == 0xfe)
                {
                    i++;
                }
                //4th byte = command, length and data
                else if (i >= PacketBytes.STATION_NUMBER)
                {
                    //incorrect length
                    if (i == PacketBytes.LENGTH && data[PacketBytes.LENGTH] > (254 - PacketBytes.DATA_START))
                    {
                        return "Incorrect length";
                    }

                    //packet is received
                    if (i >= PacketBytes.DATA_START + data[PacketBytes.LENGTH])
                    {
                        //crc matching
                        if (data[i] == Accessory.crcCalc(data, PacketBytes.STATION_NUMBER, i - 1))
                        {
                            string result = "";
                            //result += "Package is correct\r\n";
                            result += executeCommand(data);
                            return result;

                        }
                        else // CRC not correct
                        {
                            return "CRC not correct";
                        }
                    }
                    i++;
                }
                else
                {
                    return "Incorrect byte";
                }
            }
            return "Incorrect package";
        }

        private string executeCommand(byte[] data)
        {
            string result = "";
            switch (data[PacketBytes.COMMAND])
            {
                case Reply.SET_MODE:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.SET_MODE || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_setMode(data);
                    break;
                case Reply.SET_TIME:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.SET_TIME || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_setTime(data);
                    break;
                case Reply.RESET_STATION:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.RESET_STATION || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_resetStation(data);
                    break;
                case Reply.GET_STATUS:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.GET_STATUS || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_getStatus(data);
                    break;
                case Reply.INIT_CHIP:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.INIT_CHIP || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_initChip(data);
                    break;
                case Reply.GET_LAST_TEAM:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.GET_LAST_TEAM || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_getLastTeam(data);
                    break;
                case Reply.GET_CHIP_HISTORY:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.GET_CHIP_HISTORY || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_getChipHistory(data);
                    break;
                case Reply.READ_CARD_PAGE:
                    if (data[PacketBytes.LENGTH] >= ReplyDataLength.READ_CARD_PAGE || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_readCardPage(data);
                    break;
                case Reply.UPDATE_TEAM_MASK:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.UPDATE_TEAM_MASK || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_updateTeamMask(data);
                    break;
                case Reply.WRITE_CARD_PAGE:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.WRITE_CARD_PAGE || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_writeCardPage(data);
                    break;
                case Reply.READ_FLASH:
                    if (data[PacketBytes.LENGTH] >= ReplyDataLength.READ_FLASH || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_readFlash(data);
                    break;
                case Reply.WRITE_FLASH:
                    if (data[PacketBytes.LENGTH] == ReplyDataLength.WRITE_FLASH || (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0))
                        result = reply_writeFlash(data);
                    break;
                default:
                    result = "Command: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\nIncorrect data length";
                    break;
            }
            return result;
        }

        private string reply_setMode(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            return result;
        }

        private string reply_setTime(byte[] data)
        {
            //0: код ошибки
            //1-4: текущее время
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            long t = data[PacketBytes.DATA_START + 1] * 16777216 + data[PacketBytes.DATA_START + 2] * 65536 + data[PacketBytes.DATA_START + 3] * 256 + data[PacketBytes.DATA_START + 4];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tНовое время: " + getDateToString(d) + "\r\n";
            return result;
        }

        private string reply_resetStation(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            return result;
        }

        private string reply_getStatus(byte[] data)
        {
            string result = "";
            //0: код ошибки
            //1: версия прошивки
            //2: номер режима
            //3-6: текущее время
            //7-8: количество отметок на станции
            //9-12: время последней отметки на станции
            //13-14: напряжение батареи в условных единицах[0..1023] ~ [0..1.1В]
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            result += "\tПрошивка: " + data[PacketBytes.DATA_START + 1].ToString() + "\r\n";
            result += "\tРежим: " + StationModeStrings[data[PacketBytes.DATA_START + 2]] + "\r\n";

            long t = data[PacketBytes.DATA_START + 3] * 16777216 + data[PacketBytes.DATA_START + 4] * 65536 + data[PacketBytes.DATA_START + 5] * 256 + data[PacketBytes.DATA_START + 6];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tВремя: " + getDateToString(d) + "\r\n";

            int n = data[PacketBytes.DATA_START + 7] * 256 + data[PacketBytes.DATA_START + 8];
            result += "\tКол-во отметок#: " + n.ToString() + "\r\n";

            t = data[PacketBytes.DATA_START + 9] * 16777216 + data[PacketBytes.DATA_START + 10] * 65536 + data[PacketBytes.DATA_START + 11] * 256 + data[PacketBytes.DATA_START + 12];
            d = ConvertFromUnixTimestamp(t);
            result += "\tВремя последней отметки: " + getDateToString(d) + "\r\n";

            n = data[PacketBytes.DATA_START + 13] * 256 + data[PacketBytes.DATA_START + 14];
            result += "\tБатарея: " + n.ToString() + "\r\n";

            n = data[PacketBytes.DATA_START + 15] * 256 + data[PacketBytes.DATA_START + 16];
            result += "\tТемпература: " + n.ToString() + "\r\n";

            /*t = data[PacketBytes.DATA_START + 16] * 16777216 + data[PacketBytes.DATA_START + 17] * 65536 + data[PacketBytes.DATA_START + 18] * 256 + data[PacketBytes.DATA_START + 19];
            result += "\tРазмер  флэш-памяти: " + t.ToString() + " байт\r\n";*/


            return result;
        }

        private string reply_initChip(byte[] data)
        {
            //0: код ошибки
            // убрать 1-7: UID чипа
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            result += "\tВремя инициализации: ";
            long t = data[PacketBytes.DATA_START + 1] * 16777216 + data[PacketBytes.DATA_START + 2] * 65536 + data[PacketBytes.DATA_START + 3] * 256 + data[PacketBytes.DATA_START + 4];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += getDateToString(d) + "\r\n";

            result += "\tUID: ";
            for (int i = 1; i <= 8; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START + i]);
            result += "\r\n";
            return result;
        }

        private string reply_getLastTeam(byte[] data)
        {
            //0: код ошибки
            //1-2: номер чипа
            //3-6: время инициализации
            //7-8: маска команды	
            //9-12: время последней отметки на станции
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            int n = data[PacketBytes.DATA_START + 1] * 256 + data[PacketBytes.DATA_START + 2];
            result += "\tЧип#: " + n.ToString() + "\r\n";

            long t = data[PacketBytes.DATA_START + 3] * 16777216 + data[PacketBytes.DATA_START + 4] * 65536 + data[PacketBytes.DATA_START + 5] * 256 + data[PacketBytes.DATA_START + 6];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tВремя инициализации: " + getDateToString(d) + "\r\n";

            n = data[PacketBytes.DATA_START + 7] * 256 + data[PacketBytes.DATA_START + 8];
            result += "\tМаска команды: " + n.ToString() + "\r\n";

            t = data[PacketBytes.DATA_START + 9] * 16777216 + data[PacketBytes.DATA_START + 10] * 65536 + data[PacketBytes.DATA_START + 11] * 256 + data[PacketBytes.DATA_START + 12];
            d = ConvertFromUnixTimestamp(t);
            result += "\tВремя последней отметки: " + getDateToString(d) + "\r\n";

            return result;
        }

        private string reply_getChipHistory(byte[] data)
        {
            //0: код ошибки
            //1 - n: данные отметившихся команд
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            int n = data[PacketBytes.DATA_START + 1] * 256 + data[PacketBytes.DATA_START + 2];
            result += "\tЧип#: " + n.ToString() + "\r\n";

            long t = data[PacketBytes.DATA_START + 3] * 16777216 + data[PacketBytes.DATA_START + 4] * 65536 + data[PacketBytes.DATA_START + 5] * 256 + data[PacketBytes.DATA_START + 6];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tВремя инициализации: " + getDateToString(d) + "\r\n";

            n = data[PacketBytes.DATA_START + 7] * 256 + data[PacketBytes.DATA_START + 8];
            result += "\tМаска команды: " + n.ToString() + "\r\n";

            t = data[PacketBytes.DATA_START + 9] * 16777216 + data[PacketBytes.DATA_START + 10] * 65536 + data[PacketBytes.DATA_START + 11] * 256 + data[PacketBytes.DATA_START + 12];
            d = ConvertFromUnixTimestamp(t);
            result += "\tВремя последней отметки: " + getDateToString(d) + "\r\n";

            //!!!!!!!!!!!!!!!! Доработать!!!!!!!!!!!!!!!!!
            /*this.Invoke((MethodInvoker)delegate
            {
                foreach (var team in teamContent)
                {
                    string tmpMask = "";
                    for (int i = 7; i >= 0; i--)
                        tmpMask += Accessory.GetBit((byte)(team.teamMask >> 8), (byte)i) ? "1" : "0";
                    for (int i = 7; i >= 0; i--)
                        tmpMask += Accessory.GetBit((byte)team.teamMask, (byte)i) ? "1" : "0";
                    dataGridView_teams.Rows.Add(team.teamNumber.ToString(), getDateToString(team.checkInTime), tmpMask);
                }
            });*/

            return result;
        }

        private string reply_readCardPage(byte[] data)
        {
            //0: код ошибки
            //1-7: UID чипа
            //8-11: данные из страницы карты(4 байта)
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result.ToString();

            result += "\tUID: ";
            for (int i = 1; i <= 8; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START + i]);
            result += "\r\n";

            result += "\tДанные с карты:\r\n";
            int n = 0;
            List<chipData> cardContent = new List<chipData>();
            chipData tmpPage = new chipData();
            for (int i = 9; i < data[PacketBytes.LENGTH]; i++)
            {
                if (n == 0)
                {
                    result += "\t\tPage" + data[PacketBytes.DATA_START + i].ToString("D2") + ": ";
                    tmpPage.pageNumber = data[PacketBytes.DATA_START + i];
                }
                else
                {
                    result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START + i]);
                    tmpPage.pageData[n - 1] = data[PacketBytes.DATA_START + i];
                }
                n++;
                if (n > 4)
                {
                    cardContent.Add(tmpPage);
                    tmpPage = new chipData();
                    result += "\r\n";
                    n = 0;
                }
            }
            result += "\r\n";

            this.Invoke((MethodInvoker)delegate
            {
                foreach (var chip in cardContent)
                {
                    dataGridView_rawData.Rows[chip.pageNumber].Cells[1].Value = Accessory.ConvertByteArrayToHex(chip.pageData);
                    if (chip.pageNumber > 7 && chip.pageData[0] != 0 && chip.pageData[1] != 0 && chip.pageData[2] != 0 && chip.pageData[3] != 0)
                    {
                        byte todayByte = (byte)(ConvertToUnixTimestamp(DateTime.Now) >> 24);
                        long m = todayByte * 16777216 + chip.pageData[1] * 65536 + chip.pageData[2] * 256 + chip.pageData[3];
                        DateTime t = ConvertFromUnixTimestamp(m);
                        dataGridView_rawData.Rows[chip.pageNumber].Cells[2].Value = "KP#" + chip.pageData[0].ToString() + ", " + getDateToString(t);
                    }
                    else if (chip.pageNumber == 4)
                    {
                        uint m = (uint)(chip.pageData[0] * 256 + chip.pageData[1]);
                        dataGridView_rawData.Rows[chip.pageNumber].Cells[2].Value = "#" + m.ToString() + ", " + "Ntag" + chip.pageData[2].ToString() + ", v." + chip.pageData[3].ToString();
                    }
                    else if (chip.pageNumber == 5)
                    {
                        long m = chip.pageData[0] * 16777216 + chip.pageData[1] * 65536 + chip.pageData[2] * 256 + chip.pageData[3];
                        DateTime t = ConvertFromUnixTimestamp(m);
                        dataGridView_rawData.Rows[chip.pageNumber].Cells[2].Value = getDateToString(t);
                    }
                    else if (chip.pageNumber == 6)
                    {
                        string tmp = "";
                        for (int i = 7; i >= 0; i--)
                            tmp += Accessory.GetBit(chip.pageData[0], (byte)i) ? "1" : "0";
                        for (int i = 7; i >= 0; i--)
                            tmp += Accessory.GetBit(chip.pageData[1], (byte)i) ? "1" : "0";
                        dataGridView_rawData.Rows[chip.pageNumber].Cells[2].Value = tmp;
                    }
                }
            });
            return result;
        }

        private string reply_updateTeamMask(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            return result;
        }

        private string reply_writeCardPage(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            return result;
        }

        private string reply_readFlash(byte[] data)
        {
            //0: код ошибки
            //1...: данные из флэша
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            result += "\tДанные флэш: ";
            for (int i = 1; i < data[PacketBytes.LENGTH]; i++)
            {
                result += " " + Accessory.ConvertByteToHex(data[PacketBytes.DATA_START + i]);
            }
            result += "\r\n";

            return result;
        }

        private string reply_writeFlash(byte[] data)
        {
            //0: код ошибки
            //1...: данные из флэша
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START]] + "\r\n";
            if (data[PacketBytes.LENGTH] == 1 && data[PacketBytes.DATA_START] > 0)
                return result;

            result += "\tЗаписано байт: " + data[PacketBytes.DATA_START + 1].ToString() + "\r\n";
            return result;
        }

        #endregion

        #region Helpers
        private delegate void SetTextCallback1(string text);
        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (textBox_terminal.InvokeRequired)
            {
                SetTextCallback1 d = new SetTextCallback1(SetText);
                BeginInvoke(d, new object[] { text });
            }
            else
            {
                textBox_terminal.Text += text;
            }
        }

        private string getDateToString(DateTime date)
        {
            string dateString = date.Year.ToString("D4")
                        + "." + date.Month.ToString("D2")
                        + "." + date.Day.ToString("D2")
                        + " " + date.Hour.ToString("D2")
                        + ":" + date.Minute.ToString("D2")
                        + ":" + date.Second.ToString("D2");
            return dateString;
        }

        private byte[] DateStringToByteArray(string dateString)
        {
            //"2019.04.01 12:00:00";
            byte[] dateArray = new byte[6] { 0, 0, 0, 0, 0, 0 };
            if (dateString.Length == 19
                && dateString[4] == '.'
                && dateString[7] == '.'
                && dateString[10] == ' '
                && dateString[13] == ':'
                && dateString[16] == ':')
            {
                dateArray[0] = byte.Parse(dateString.Substring(2, 2));
                dateArray[1] = byte.Parse(dateString.Substring(5, 2));
                dateArray[2] = byte.Parse(dateString.Substring(8, 2));
                dateArray[3] = byte.Parse(dateString.Substring(11, 2));
                dateArray[4] = byte.Parse(dateString.Substring(14, 2));
                dateArray[5] = byte.Parse(dateString.Substring(17, 2));
            }

            return dateArray;
        }

        private long DateStringToUnixTime(string dateString)
        {
            //"2019.04.01 12:00:00";
            long unixTime = 0;
            if (dateString.Length == 19
                && dateString[4] == '.'
                && dateString[7] == '.'
                && dateString[10] == ' '
                && dateString[13] == ':'
                && dateString[16] == ':')
            {
                int year = int.Parse(dateString.Substring(0, 4));
                int mon = int.Parse(dateString.Substring(5, 2));
                int day = int.Parse(dateString.Substring(8, 2));
                int hh = int.Parse(dateString.Substring(11, 2));
                int mm = int.Parse(dateString.Substring(14, 2));
                int ss = int.Parse(dateString.Substring(17, 2));
                DateTime date = new DateTime(year, mon, day, hh, mm, ss);
                unixTime = ConvertToUnixTimestamp(date);
            }

            return unixTime;
        }

        private static DateTime ConvertFromUnixTimestamp(long timestamp)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return origin.AddSeconds(timestamp);
        }

        private static long ConvertToUnixTimestamp(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            TimeSpan diff = date - origin;
            return (long)diff.TotalSeconds;
        }

        private void checkBox_autoTime_CheckedChanged(object sender, EventArgs e)
        {
            textBox_setTime.Enabled = !checkBox_autoTime.Checked;
            textBox_setTime.Text = getDateToString(DateTime.Now);
        }

        private void comboBox_chipType_SelectedIndexChanged(object sender, EventArgs e)
        {
            int pageNum = 0;
            if (comboBox_chipType.SelectedItem.ToString() == "Ntag213")
                pageNum = 44;
            else if (comboBox_chipType.SelectedItem.ToString() == "Ntag215")
                pageNum = 134;
            else if (comboBox_chipType.SelectedItem.ToString() == "Ntag216")
                pageNum = 230;
            dataGridView_rawData.Rows.Clear();
            for (int i = 0; i < pageNum; i++)
            {
                if (pageNum == 44 && i >= 40)
                    dataGridView_rawData.Rows.Add("Reserved");
                else if (pageNum == 134 && i >= 130)
                    dataGridView_rawData.Rows.Add("Reserved");
                else if (pageNum == 230 && i >= 226)
                    dataGridView_rawData.Rows.Add("Reserved");
                else if (i > 7)
                    dataGridView_rawData.Rows.Add(i.ToString("D2") + ": KP#, time[3]");
                else if (i == 0)
                    dataGridView_rawData.Rows.Add("UID0");
                else if (i == 1)
                    dataGridView_rawData.Rows.Add("UID1");
                else if (i == 2)
                    dataGridView_rawData.Rows.Add("UID2");
                else if (i == 3)
                    dataGridView_rawData.Rows.Add("UID3");
                else if (i == 4)
                    dataGridView_rawData.Rows.Add("Team#[2],ChipType,FwVer");
                else if (i == 5)
                    dataGridView_rawData.Rows.Add("InitDate");
                else if (i == 6)
                    dataGridView_rawData.Rows.Add("TeamMask[2]");
                else if (i == 7)
                    dataGridView_rawData.Rows.Add("Reserved");
            }
        }

        private void button_dumpChip_Click(object sender, EventArgs e)
        {

        }
        #endregion
    }
}
