﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;


namespace BC_Logger_control
{
    public partial class Form1 : Form
    {
        private const int inputCodePage = 866;

        public static System.Timers.Timer aTimer;
        private bool packetReady = false;
        private long timeout = 500;

        //команды
        private static class Command
        {
            public static byte SET_MODE = 0x80;
            public static byte SET_TIME = 0x81;
            public static byte RESET_STATION = 0x82;
            public static byte GET_STATUS = 0x83;
            public static byte INIT_CHIP = 0x84;
            public static byte GET_LAST_TEAM = 0x85;
            public static byte GET_CHIP_HISTORY = 0x86;
            public static byte READ_CARD_PAGE = 0x87;
            public static byte UPDATE_TEAM_MASK = 0x88;
            public static byte WRITE_CARD_PAGE = 0x89;
        }
        //размеры данных для команд header[6]+crc[1]+data[?]
        private static class CommandDataLength
        {
            public const byte SET_MODE = 6 + 1 + 1;
            public const byte SET_TIME = 6 + 1 + 6;
            public const byte RESET_STATION = 6 + 1 + 7;
            public const byte GET_STATUS = 6 + 1;
            public const byte INIT_CHIP = 6 + 1 + 4;
            public const byte GET_LAST_TEAM = 6 + 1;
            public const byte GET_CHIP_HISTORY = 6 + 1 + 4;
            public const byte READ_CARD_PAGE = 6 + 1 + 1;
            public const byte UPDATE_TEAM_MASK = 6 + 1 + 8;
            public const byte WRITE_CARD_PAGE = 6 + 1 + 13;
        }

        //ответы станции
        private static class Reply
        {
            public const byte SET_MODE = 0x90;
            public const byte SET_TIME = 0x91;
            public const byte RESET_STATION = 0x92;
            public const byte GET_STATUS = 0x93;
            public const byte INIT_CHIP = 0x94;
            public const byte GET_LAST_TEAM = 0x95;
            public const byte GET_CHIP_HISTORY = 0x96;
            public const byte READ_CARD_PAGE = 0x97;
            public const byte UPDATE_TEAM_MASK = 0x98;
            public const byte WRITE_CARD_PAGE = 0x99;
        }
        //размеры данных для ответов
        private static class ReplyDataLength
        {
            public static byte SET_MODE = 1;
            public static byte SET_TIME = 5;
            public static byte RESET_STATION = 1;
            public static byte GET_STATUS = 15;
            public static byte INIT_CHIP = 9;
            public static byte GET_LAST_TEAM = 19;
            public static byte GET_CHIP_HISTORY = 255;
            public static byte READ_CARD_PAGE = 13;
            public static byte UPDATE_TEAM_MASK = 1;
            public static byte WRITE_CARD_PAGE = 1;
        }

        private string[] ReplyStrings = new string[]
        {
            "SET_MODE",
            "SET_TIME",
            "RESET_STATION",
            "GET_STATUS",
            "INIT_CHIP",
            "GET_LAST_TEAM",
            "GET_CHIP_HISTORY",
            "READ_CARD_PAGE",
            "UPDATE_TEAM_MASK",
            "WRITE_CARD_PAGE"
        };

        //режимы станции
        private string[] StationModeStrings = new string[]
        {
            "INIT",
            "START_KP",
            "FINISH_KP"
        };

        //коды ошибок станции
        private string[] errorCodesStrings = new string[]
        {
            "OK",
            "WRONG_STATION",
            "READ_ERROR",
            "WRITE_ERROR",
            "LOW_INIT_TIME",
            "WRONG_CHIP",
            "NO_CHIP",
            "BUFFER_OVERFLOW",
            "INCORRECT_DATA",
            "INCORRECT_UID"
        };

        //header 0xFE [0-2] + station#[3] + len[4] + cmd#[5] + data[6]... + crc
        private static class PacketBytes
        {
            public static byte STATION_NUMBER_BYTE = 3;
            public static byte LENGTH_BYTE = 4;
            public static byte COMMAND_BYTE = 5;
            public static byte DATA_START_BYTE = 6;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.Encoding = Encoding.GetEncoding(inputCodePage);
            //Serial init
            comboBox_portName.Items.Add("None");
            foreach (string portname in SerialPort.GetPortNames())
            {
                comboBox_portName.Items.Add(portname); //добавить порт в список
            }
            if (comboBox_portName.Items.Count == 1)
            {
                comboBox_portName.SelectedIndex = 0;
                button_openPort.Enabled = false;
            }
            else
                comboBox_portName.SelectedIndex = 0;
            textBox_setTime.Text = getDateToString();
            comboBox_mode.SelectedIndex = 0;
        }

        #region COM_ports
        private void button_refresh_Click(object sender, EventArgs e)
        {
            comboBox_portName.Items.Clear();
            comboBox_portName.Items.Add("None");
            foreach (string portname in SerialPort.GetPortNames())
            {
                comboBox_portName.Items.Add(portname); //добавить порт в список
            }
            if (comboBox_portName.Items.Count == 1)
            {
                comboBox_portName.SelectedIndex = 0;
                button_openPort.Enabled = false;
            }
            else
                comboBox_portName.SelectedIndex = 0;


            Hashtable PortNames = new Hashtable();
            string[] ports = System.IO.Ports.SerialPort.GetPortNames();
            if (ports.Length == 0)
            {
                textBox_terminal.Text += "ERROR: No COM ports exist\n\r";
            }
            else
            {
                PortNames = Accessory.BuildPortNameHash(ports);
                foreach (String s in PortNames.Keys)
                {
                    textBox_terminal.Text += "\n\r" + PortNames[s] + ": " + s + "\n\r";
                }
            }



        }

        private void button_openPort_Click(object sender, EventArgs e)
        {
            //if (serialPort1.IsOpen == true) comboBox_portName.SelectedIndex=0;
            if (comboBox_portName.SelectedIndex != 0)
            {
                //comboBox_portname1.Enabled = false;
                serialPort1.PortName = comboBox_portName.Text;
                serialPort1.BaudRate = 9600;
                serialPort1.DataBits = 8;
                serialPort1.Parity = Parity.None;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Handshake = Handshake.None;
                serialPort1.ReadTimeout = 500;
                serialPort1.WriteTimeout = 500;
                try
                {
                    serialPort1.Open();
                }
                catch (Exception ex)
                {
                    SetText("Error opening port " + serialPort1.PortName + ": " + ex.Message);
                }
                //while (serialPort1.IsOpen == false) ;


                button_getLastTeam.Enabled = true;
                button_getChipsHistory.Enabled = true;
                button_updTeamMask.Enabled = true;
                button_initChip.Enabled = true;
                button_readChipPage.Enabled = true;
                button_writeChipPage.Enabled = true;

                button_setMode.Enabled = true;
                button_resetStation.Enabled = true;
                button_setTime.Enabled = true;
                button_getStatus.Enabled = true;
                button_getStatus.Enabled = true;

                button_closePort.Enabled = true;
                button_openPort.Enabled = false;
                button_refresh.Enabled = false;
                comboBox_portName.Enabled = false;
                //aTimer.Enabled = true;
            }
        }

        private void button_closePort_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception ex)
                {
                    SetText("Error closing port " + serialPort1.PortName + ": " + ex.Message);
                }
            }


            button_getLastTeam.Enabled = false;
            button_getChipsHistory.Enabled = false;
            button_updTeamMask.Enabled = false;
            button_initChip.Enabled = false;
            button_readChipPage.Enabled = false;
            button_writeChipPage.Enabled = false;

            button_setMode.Enabled = false;
            button_resetStation.Enabled = false;
            button_setTime.Enabled = false;
            button_getStatus.Enabled = false;
            button_getStatus.Enabled = false;


            //aTimer.Enabled = false;
            button_closePort.Enabled = false;
            button_openPort.Enabled = true;
            button_refresh.Enabled = true;
            comboBox_portName.Enabled = true;
        }

        //rewrite to validate packet runtime
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            Accessory.Delay_ms(timeout);
            if (checkBox_portMon.Checked)
            {
                List<byte> rx = new List<byte>();
                while (serialPort1.BytesToRead > 0)
                {
                    rx.Add((byte)serialPort1.ReadByte());
                }
                SetText("<< " + Accessory.ConvertByteArrayToHex(rx.ToArray()) + "\r\n");
                string parseResult = parsePackage(rx.ToArray()) + "\r\n";
                SetText(parseResult + "\r\n");
            }
        }

        private void serialPort1_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            SetText("COM port error: " + e.ToString() + "\r\n");
        }

        private void sendCommand(byte[] command)
        {
            command[0] = 0xFE;
            command[1] = 0xFE;
            command[2] = 0xFE;
            command[PacketBytes.STATION_NUMBER_BYTE] = byte.Parse(textBox_stationNumber.Text);
            command[PacketBytes.LENGTH_BYTE] = (byte)(command.Length - PacketBytes.DATA_START_BYTE - 1);
            command[command.Length - 1] = Accessory.crcCalc(command, PacketBytes.STATION_NUMBER_BYTE, command.Length - 2);
            serialPort1.Write(command, 0, command.Length);
            SetText(">> "
                + Accessory.ConvertByteArrayToHex(command)
                + "\r\n");
        }
        #endregion

        #region Terminal_window
        private void textBox_terminal_TextChanged(object sender, EventArgs e)
        {
            if (checkBox_autoScroll.Checked == true)
            {
                textBox_terminal.SelectionStart = textBox_terminal.Text.Length;
                textBox_terminal.ScrollToCaret();
            }
        }
        private void button_clear_Click(object sender, EventArgs e)
        {
            textBox_terminal.Text = "";
        }

        private void button_saveFile_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            File.WriteAllText(saveFileDialog1.FileName, textBox_terminal.Text);
        }
        #endregion

        #region Generate commands
        private void button_setMode_Click(object sender, EventArgs e)
        {
            byte[] setMode = new byte[CommandDataLength.SET_MODE];
            setMode[PacketBytes.COMMAND_BYTE] = Command.SET_MODE;

            //0: новый номер режима
            setMode[PacketBytes.DATA_START_BYTE] = (byte)comboBox_mode.SelectedIndex;
            sendCommand(setMode);
        }

        private void button_setTime_Click(object sender, EventArgs e)
        {
            byte[] setTime = new byte[CommandDataLength.SET_TIME];
            setTime[PacketBytes.COMMAND_BYTE] = Command.SET_TIME;

            //0-5: дата и время[yy.mm.dd hh: mm:ss]
            if (checkBox_autoTime.Checked)
                textBox_setTime.Text = getDateToString();
            byte[] date = DateStringToByteArray(textBox_setTime.Text);
            if (date.Length != 6)
                return;
            for (int i = 0; i < 6; i++)
                setTime[PacketBytes.DATA_START_BYTE + i] = date[i];

            //0-3: дата и время в unixtime
            /*if (checkBox_autoTime.Checked) textBox_setTime.Text = getDateToString();
            long tmpTime = DateStringToUnixTime(textBox_setTime.Text);
            setTime[PacketBytes.DATA_START_BYTE + 0] = (byte)((tmpTime & 0xFF000000) >> 24);
            setTime[PacketBytes.DATA_START_BYTE + 1] = (byte)((tmpTime & 0x00FF0000) >> 16);
            setTime[PacketBytes.DATA_START_BYTE + 2] = (byte)((tmpTime & 0x0000FF00) >> 8);
            setTime[PacketBytes.DATA_START_BYTE + 3] = (byte)(tmpTime & 0x000000FF);*/

            sendCommand(setTime);
        }

        private void button_resetStation_Click(object sender, EventArgs e)
        {
            byte[] resetStation = new byte[CommandDataLength.RESET_STATION];
            resetStation[PacketBytes.COMMAND_BYTE] = Command.RESET_STATION;

            /*0: новый номер станции
			1-2: кол-во отмеченных карт (для сверки)
			3-6: время последней отметки unixtime(для сверки)*/
            resetStation[PacketBytes.DATA_START_BYTE] = byte.Parse(textBox_newStationNumber.Text);

            uint chipsNumber = uint.Parse(textBox_checkedChips.Text);
            resetStation[PacketBytes.DATA_START_BYTE + 1] = (byte)(chipsNumber >> 2);
            resetStation[PacketBytes.DATA_START_BYTE + 2] = (byte)(chipsNumber & 0x00ff);

            long tmpTime = DateStringToUnixTime(textBox_lastCheck.Text);
            resetStation[PacketBytes.DATA_START_BYTE + 3] = (byte)((tmpTime & 0xFF000000) >> 24);
            resetStation[PacketBytes.DATA_START_BYTE + 4] = (byte)((tmpTime & 0x00FF0000) >> 16);
            resetStation[PacketBytes.DATA_START_BYTE + 5] = (byte)((tmpTime & 0x0000FF00) >> 8);
            resetStation[PacketBytes.DATA_START_BYTE + 6] = (byte)(tmpTime & 0x000000FF);

            sendCommand(resetStation);
        }

        private void button_getStatus_Click(object sender, EventArgs e)
        {
            byte[] getStatus = new byte[CommandDataLength.GET_STATUS];
            getStatus[PacketBytes.COMMAND_BYTE] = Command.GET_STATUS;

            sendCommand(getStatus);
        }

        private void button_initChip_Click(object sender, EventArgs e)
        {
            byte[] initChip = new byte[CommandDataLength.INIT_CHIP];
            initChip[PacketBytes.COMMAND_BYTE] = Command.INIT_CHIP;

            /*0-1: номер команды
			2-3: маска участников*/
            uint cmd = uint.Parse(textBox_commandNumber.Text);
            initChip[PacketBytes.DATA_START_BYTE] = (byte)(cmd >> 2);
            initChip[PacketBytes.DATA_START_BYTE + 1] = (byte)(cmd & 0x00ff);

            //current time is obsolete
            uint mask = uint.Parse(textBox_teamMask.Text);
            initChip[PacketBytes.DATA_START_BYTE + 2] = (byte)(mask >> 2);
            initChip[PacketBytes.DATA_START_BYTE + 3] = (byte)(mask & 0x00ff);

            sendCommand(initChip);
        }

        private void button_getLastTeam_Click(object sender, EventArgs e)
        {
            byte[] getLastTeam = new byte[CommandDataLength.GET_LAST_TEAM];
            getLastTeam[PacketBytes.COMMAND_BYTE] = Command.GET_LAST_TEAM;

            sendCommand(getLastTeam);
        }

        private void button_getChipHistory_Click(object sender, EventArgs e)
        {
            byte[] getChipHistory = new byte[CommandDataLength.GET_CHIP_HISTORY];
            getChipHistory[PacketBytes.COMMAND_BYTE] = Command.GET_CHIP_HISTORY;

            /*0-1: с какой записи
			2-3: по какую запись*/
            uint from = uint.Parse(textBox_getLn.Text.Substring(0, textBox_getLn.Text.IndexOf("-")).Trim());
            getChipHistory[PacketBytes.DATA_START_BYTE] = (byte)(from >> 2);
            getChipHistory[PacketBytes.DATA_START_BYTE + 1] = (byte)(from & 0x00ff);

            uint to = uint.Parse(textBox_getLn.Text.Substring(textBox_getLn.Text.IndexOf("-") + 1).Trim());
            getChipHistory[PacketBytes.DATA_START_BYTE + 2] = (byte)(to >> 2);
            getChipHistory[PacketBytes.DATA_START_BYTE + 3] = (byte)(to & 0x00ff);

            sendCommand(getChipHistory);
        }

        private void button_readCardPage_Click(object sender, EventArgs e)
        {
            byte[] readCardPage = new byte[CommandDataLength.READ_CARD_PAGE];
            readCardPage[PacketBytes.COMMAND_BYTE] = Command.READ_CARD_PAGE;

            //0: какую страницу карты
            readCardPage[PacketBytes.DATA_START_BYTE] = byte.Parse(textBox_readChipPage.Text);

            sendCommand(readCardPage);
        }

        private void button_updateTeamMask_Click(object sender, EventArgs e)
        {
            byte[] updateTeamMask = new byte[CommandDataLength.UPDATE_TEAM_MASK];
            updateTeamMask[PacketBytes.COMMAND_BYTE] = Command.UPDATE_TEAM_MASK;

            /*0-1: номер команды
			2-5: время выдачи чипа
			6-7: маска участников*/
            uint cmd = uint.Parse(textBox_commandNumber.Text);
            updateTeamMask[PacketBytes.DATA_START_BYTE] = (byte)(cmd >> 2);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 1] = (byte)(cmd & 0x00ff);

            //card issue time - 4 byte
            //textBox_issueTime.Text
            long tmpTime = DateStringToUnixTime(textBox_issueTime.Text);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 2] = (byte)((tmpTime & 0xFF000000) >> 24);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 3] = (byte)((tmpTime & 0x00FF0000) >> 16);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 4] = (byte)((tmpTime & 0x0000FF00) >> 8);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 5] = (byte)(tmpTime & 0x000000FF);


            uint mask = uint.Parse(textBox_teamMask.Text);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 6] = (byte)(mask >> 2);
            updateTeamMask[PacketBytes.DATA_START_BYTE + 7] = (byte)(mask & 0x00ff);

            sendCommand(updateTeamMask);
        }

        private void button_writeCardPage_Click(object sender, EventArgs e)
        {
            byte[] writeCardPage = new byte[CommandDataLength.WRITE_CARD_PAGE];
            writeCardPage[PacketBytes.COMMAND_BYTE] = Command.WRITE_CARD_PAGE;

            //0-7: UID чипа
            //8: номер страницы
            //9-12: данные из страницы карты (4 байта)
            byte[] uid = Accessory.ConvertHexToByteArray(textBox_uid.Text);
            if (uid.Length != 8)
                return;
            for (int i = 0; i <= 7; i++)
                writeCardPage[PacketBytes.DATA_START_BYTE + i] = uid[i];

            writeCardPage[PacketBytes.DATA_START_BYTE + 8] = byte.Parse(textBox_writeChipPage.Text);

            byte[] data = Accessory.ConvertHexToByteArray(textBox_data.Text);

            if (data.Length != 4)
                return;
            for (int i = 0; i <= 3; i++)
                writeCardPage[PacketBytes.DATA_START_BYTE + 9 + i] = data[i];

            sendCommand(writeCardPage);
        }

        #endregion

        #region Parse replies
        private string parsePackage(byte[] data)
        {
            int i = 0;
            while (i < data.Length)
            {
                int c = data[i];
                //0 byte = FE
                if (i == 0 && c == 0xfe)
                {
                    i++;
                }
                //1st byte = FE
                else if (i == 1 && c == 0xfe)
                {
                    i++;
                }
                //2nd byte = FE
                else if (i == 2 && c == 0xfe)
                {
                    i++;
                }
                //4th byte = command, length and data
                else if (i >= PacketBytes.STATION_NUMBER_BYTE)
                {
                    //incorrect length
                    if (i == PacketBytes.LENGTH_BYTE && data[PacketBytes.LENGTH_BYTE] > (254 - PacketBytes.DATA_START_BYTE))
                    {
                        return "Incorrect length";
                    }

                    //packet is received
                    if (i >= PacketBytes.DATA_START_BYTE + data[PacketBytes.LENGTH_BYTE])
                    {
                        //crc matching
                        if (data[i] == Accessory.crcCalc(data, PacketBytes.STATION_NUMBER_BYTE, i - 1))
                        {
                            string result = "";
                            //result += "Package is correct\r\n";
                            result += executeCommand(data);
                            return result;

                        }
                        else // CRC not correct
                        {
                            return "CRC not correct";
                        }
                    }
                    i++;
                }
                else
                {
                    return "Incorrect byte";
                }
            }
            return "Incorrect package";
        }

        private string executeCommand(byte[] data)
        {
            string result = "";
            switch (data[PacketBytes.COMMAND_BYTE])
            {
                case Reply.SET_MODE:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.SET_MODE || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_setMode(data);
                    break;
                case Reply.SET_TIME:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.SET_TIME || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_setTime(data);
                    break;
                case Reply.RESET_STATION:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.RESET_STATION || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_resetStation(data);
                    break;
                case Reply.GET_STATUS:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.GET_STATUS || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_getStatus(data);
                    break;
                case Reply.INIT_CHIP:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.INIT_CHIP || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_initChip(data);
                    break;
                case Reply.GET_LAST_TEAM:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.GET_LAST_TEAM || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_getLastTeam(data);
                    break;
                case Reply.GET_CHIP_HISTORY:
                    result = reply_getChipHistory(data);
                    break;
                case Reply.READ_CARD_PAGE:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.READ_CARD_PAGE || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_readCardPage(data);
                    break;
                case Reply.UPDATE_TEAM_MASK:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.UPDATE_TEAM_MASK || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_updateTeamMask(data);
                    break;
                case Reply.WRITE_CARD_PAGE:
                    if (data[PacketBytes.LENGTH_BYTE] == ReplyDataLength.WRITE_CARD_PAGE || (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0))
                        result = reply_writeCardPage(data);
                    break;
                default:
                    result = "Incorrect data length";
                    break;
            }
            return result;
        }

        private string reply_setMode(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            return result;
        }

        private string reply_setTime(byte[] data)
        {
            //0: код ошибки
            //1-4: текущее время
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            if (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0) return result;

            long t = data[PacketBytes.DATA_START_BYTE + 1] * 0xffffff + data[PacketBytes.DATA_START_BYTE + 2] * 0xffff + data[PacketBytes.DATA_START_BYTE + 3] * 0xff + data[PacketBytes.DATA_START_BYTE + 4];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tНовое время: " + d.ToString() + "\r\n";
            return result;
        }

        private string reply_resetStation(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            return result;
        }

        private string reply_getStatus(byte[] data)
        {
            string result = "";
            //0: код ошибки
            //1: версия прошивки
            //2: номер режима
            //3-6: текущее время
            //7-8: количество отметок на станции
            //9-12: время последней отметки на станции
            //13-14: напряжение батареи в условных единицах[0..1023] ~ [0..1.1В]
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            if (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0) return result;

            result += "\tПрошивка: " + data[PacketBytes.DATA_START_BYTE + 1].ToString() + "\r\n";
            result += "\tРежим: " + StationModeStrings[data[PacketBytes.DATA_START_BYTE + 2]] + "\r\n";

            long t = data[PacketBytes.DATA_START_BYTE + 3] * 0xffffff + data[PacketBytes.DATA_START_BYTE + 4] * 0xffff + data[PacketBytes.DATA_START_BYTE + 5] * 0xff + data[PacketBytes.DATA_START_BYTE + 6];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tВремя: " + d.ToString() + "\r\n";

            int n = data[PacketBytes.DATA_START_BYTE + 7] * 0xff + data[PacketBytes.DATA_START_BYTE + 8];
            result += "\tКол-во отметок#: " + n.ToString() + "\r\n";

            t = data[PacketBytes.DATA_START_BYTE + 9] * 0xffffff + data[PacketBytes.DATA_START_BYTE + 10] * 0xffff + data[PacketBytes.DATA_START_BYTE + 11] * 0xff + data[PacketBytes.DATA_START_BYTE + 12];
            d = ConvertFromUnixTimestamp(t);
            result += "\tВремя последней отметки: " + d.ToString() + "\r\n";

            n = data[PacketBytes.DATA_START_BYTE + 13] * 0xff + data[PacketBytes.DATA_START_BYTE + 14];
            result += "\tБатарея: " + n.ToString() + "\r\n";

            return result;
        }

        private string reply_initChip(byte[] data)
        {
            //0: код ошибки
            //1-7: UID чипа
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            if (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0) return result;

            result += "\tUID: ";
            for (int i = 1; i <= 8; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START_BYTE + i]);
            result += "\r\n";
            return result;
        }

        private string reply_getLastTeam(byte[] data)
        {
            //0: код ошибки
            //1-2: номер чипа
            //3-6: время инициализации
            //7-14: информация из страниц 6-7
            //15-18: время последней отметки на станции
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            if (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0) return result;

            int n = data[PacketBytes.DATA_START_BYTE + 1] * 0xff + data[PacketBytes.DATA_START_BYTE + 2];
            result += "\tЧип#: " + n.ToString() + "\r\n";

            long t = data[PacketBytes.DATA_START_BYTE + 3] * 0xffffff + data[PacketBytes.DATA_START_BYTE + 4] * 0xffff + data[PacketBytes.DATA_START_BYTE + 5] * 0xff + data[PacketBytes.DATA_START_BYTE + 6];
            DateTime d = ConvertFromUnixTimestamp(t);
            result += "\tВремя инициализации: " + d.ToString() + "\r\n";

            result += "\tДанные с карты: ";
            for (int i = 7; i <= 14; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START_BYTE + i]);
            result += "\r\n";

            t = data[PacketBytes.DATA_START_BYTE + 15] * 0xffffff + data[PacketBytes.DATA_START_BYTE + 16] * 0xffff + data[PacketBytes.DATA_START_BYTE + 17] * 0xff + data[PacketBytes.DATA_START_BYTE + 18];
            d = ConvertFromUnixTimestamp(t);
            result += "\tВремя последней отметки: " + d.ToString() + "\r\n";

            return result;
        }

        private string reply_getChipHistory(byte[] data)
        {
            //0: код ошибки
            //1 - n: данные отметившихся команд
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            if (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0) return result;

            result += "\tДанные с карты: ";
            for (int i = 1; i <= data[PacketBytes.LENGTH_BYTE]; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START_BYTE + i]);
            result += "\r\n";

            return result;
        }

        private string reply_readCardPage(byte[] data)
        {
            //0: код ошибки
            //1-7: UID чипа
            //8-11: данные из страницы карты(4 байта)
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            if (data[PacketBytes.LENGTH_BYTE] == 1 && data[PacketBytes.DATA_START_BYTE] > 0) return result;

            result += "\tUID: ";
            for (int i = 1; i <= 8; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START_BYTE + i]);
            result += "\r\n";

            result += "\tДанные с карты: ";
            for (int i = 9; i <= 12; i++)
                result += Accessory.ConvertByteToHex(data[PacketBytes.DATA_START_BYTE + i]);
            result += "\r\n";

            return result;
        }

        private string reply_updateTeamMask(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            return result;
        }

        private string reply_writeCardPage(byte[] data)
        {
            //0: код ошибки
            string result = "";
            result += "Ответ:\r\n\tСтанция#: " + data[PacketBytes.STATION_NUMBER_BYTE].ToString() + "\r\n";
            result += "\tОтвет команды: " + ReplyStrings[data[PacketBytes.COMMAND_BYTE] - 0x90] + "\r\n";
            result += "\tОшибка#: " + errorCodesStrings[data[PacketBytes.DATA_START_BYTE]] + "\r\n";
            return result;
        }

        #endregion

        #region Helpers
        private delegate void SetTextCallback1(string text);
        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (textBox_terminal.InvokeRequired)
            {
                SetTextCallback1 d = new SetTextCallback1(SetText);
                BeginInvoke(d, new object[] { text });
            }
            else
            {
                textBox_terminal.Text += text;
            }
        }

        private string getDateToString()
        {
            string dateString = DateTime.Now.Year.ToString("D4")
                        + "." + DateTime.Now.Month.ToString("D2")
                        + "." + DateTime.Now.Day.ToString("D2")
                        + " " + DateTime.Now.Hour.ToString("D2")
                        + ":" + DateTime.Now.Minute.ToString("D2")
                        + ":" + DateTime.Now.Second.ToString("D2");
            return dateString;
        }

        private byte[] DateStringToByteArray(string dateString)
        {
            //"2019.04.01 12:00:00";
            byte[] dateArray = new byte[6] { 0, 0, 0, 0, 0, 0 };
            if (dateString.Length == 19
                && dateString[4] == '.'
                && dateString[7] == '.'
                && dateString[10] == ' '
                && dateString[13] == ':'
                && dateString[16] == ':')
            {
                dateArray[0] = byte.Parse(dateString.Substring(2, 2));
                dateArray[1] = byte.Parse(dateString.Substring(5, 2));
                dateArray[2] = byte.Parse(dateString.Substring(8, 2));
                dateArray[3] = byte.Parse(dateString.Substring(11, 2));
                dateArray[4] = byte.Parse(dateString.Substring(14, 2));
                dateArray[5] = byte.Parse(dateString.Substring(17, 2));
            }

            return dateArray;
        }

        private long DateStringToUnixTime(string dateString)
        {
            //"2019.04.01 12:00:00";
            long unixTime = 0;
            if (dateString.Length == 19
                && dateString[4] == '.'
                && dateString[7] == '.'
                && dateString[10] == ' '
                && dateString[13] == ':'
                && dateString[16] == ':')
            {
                int year = int.Parse(dateString.Substring(0, 4));
                int mon = int.Parse(dateString.Substring(5, 2));
                int day = int.Parse(dateString.Substring(8, 2));
                int hh = int.Parse(dateString.Substring(11, 2));
                int mm = int.Parse(dateString.Substring(14, 2));
                int ss = int.Parse(dateString.Substring(17, 2));
                DateTime date = new DateTime(year, mon, day, hh, mm, ss);
                unixTime = ConvertToUnixTimestamp(date);
            }

            return unixTime;
        }

        private static DateTime ConvertFromUnixTimestamp(long timestamp)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return origin.AddSeconds(timestamp);
        }

        private static long ConvertToUnixTimestamp(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            TimeSpan diff = date - origin;
            return (long)diff.TotalSeconds;
        }

        private void button_getPcTime_Click(object sender, EventArgs e)
        {
            textBox_setTime.Text = getDateToString();
        }

        private void checkBox_autoTime_CheckedChanged(object sender, EventArgs e)
        {
            button_pcTime.Enabled = !checkBox_autoTime.Checked;
            textBox_setTime.Enabled = !checkBox_autoTime.Checked;
            textBox_setTime.Text = getDateToString();
        }

        #endregion
    }
}
