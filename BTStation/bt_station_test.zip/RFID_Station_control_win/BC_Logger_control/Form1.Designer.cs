﻿namespace BC_Logger_control
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage_Station = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_resetStation = new System.Windows.Forms.Button();
            this.textBox_newStationNumber = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_checkedChips = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_lastCheck = new System.Windows.Forms.TextBox();
            this.button_getLastTeam = new System.Windows.Forms.Button();
            this.comboBox_mode = new System.Windows.Forms.ComboBox();
            this.checkBox_autoTime = new System.Windows.Forms.CheckBox();
            this.textBox_setTime = new System.Windows.Forms.TextBox();
            this.button_setTime = new System.Windows.Forms.Button();
            this.button_setMode = new System.Windows.Forms.Button();
            this.button_getStatus = new System.Windows.Forms.Button();
            this.tabPage_Chip = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_issueTime = new System.Windows.Forms.TextBox();
            this.textBox_records = new System.Windows.Forms.TextBox();
            this.button_updTeamMask = new System.Windows.Forms.Button();
            this.button_getChipsHistory = new System.Windows.Forms.Button();
            this.button_initChip = new System.Windows.Forms.Button();
            this.tabPage_Raw = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_uid = new System.Windows.Forms.TextBox();
            this.textBox_data = new System.Windows.Forms.TextBox();
            this.textBox_readChipPage = new System.Windows.Forms.TextBox();
            this.textBox_writeChipPage = new System.Windows.Forms.TextBox();
            this.button_readChipPage = new System.Windows.Forms.Button();
            this.button_writeChipPage = new System.Windows.Forms.Button();
            this.textBox_teamMask = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_stationNumber = new System.Windows.Forms.TextBox();
            this.textBox_terminal = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.comboBox_portName = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_openPort = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_closePort = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox_autoScroll = new System.Windows.Forms.CheckBox();
            this.button_refresh = new System.Windows.Forms.Button();
            this.checkBox_portMon = new System.Windows.Forms.CheckBox();
            this.textBox_commandNumber = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView_teams = new System.Windows.Forms.DataGridView();
            this.tabControl_teamData = new System.Windows.Forms.TabControl();
            this.tabPage_terminal = new System.Windows.Forms.TabPage();
            this.tabPage_grid = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabPage_chipContent = new System.Windows.Forms.TabPage();
            this.button_dumpChip = new System.Windows.Forms.Button();
            this.comboBox_chipType = new System.Windows.Forms.ComboBox();
            this.dataGridView_rawData = new System.Windows.Forms.DataGridView();
            this.Page = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.decoded = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.team = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TeamMask = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl.SuspendLayout();
            this.tabPage_Station.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage_Chip.SuspendLayout();
            this.tabPage_Raw.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_teams)).BeginInit();
            this.tabControl_teamData.SuspendLayout();
            this.tabPage_terminal.SuspendLayout();
            this.tabPage_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabPage_chipContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_rawData)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabPage_Station);
            this.tabControl.Controls.Add(this.tabPage_Chip);
            this.tabControl.Controls.Add(this.tabPage_Raw);
            this.tabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl.Location = new System.Drawing.Point(-2, 109);
            this.tabControl.Margin = new System.Windows.Forms.Padding(6);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(441, 361);
            this.tabControl.TabIndex = 0;
            // 
            // tabPage_Station
            // 
            this.tabPage_Station.Controls.Add(this.groupBox1);
            this.tabPage_Station.Controls.Add(this.button_getLastTeam);
            this.tabPage_Station.Controls.Add(this.comboBox_mode);
            this.tabPage_Station.Controls.Add(this.checkBox_autoTime);
            this.tabPage_Station.Controls.Add(this.textBox_setTime);
            this.tabPage_Station.Controls.Add(this.button_setTime);
            this.tabPage_Station.Controls.Add(this.button_setMode);
            this.tabPage_Station.Controls.Add(this.button_getStatus);
            this.tabPage_Station.Location = new System.Drawing.Point(4, 33);
            this.tabPage_Station.Margin = new System.Windows.Forms.Padding(6);
            this.tabPage_Station.Name = "tabPage_Station";
            this.tabPage_Station.Padding = new System.Windows.Forms.Padding(6);
            this.tabPage_Station.Size = new System.Drawing.Size(433, 324);
            this.tabPage_Station.TabIndex = 0;
            this.tabPage_Station.Text = "Station";
            this.tabPage_Station.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.button_resetStation);
            this.groupBox1.Controls.Add(this.textBox_newStationNumber);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox_checkedChips);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox_lastCheck);
            this.groupBox1.Location = new System.Drawing.Point(9, 171);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(409, 145);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Reset station";
            // 
            // button_resetStation
            // 
            this.button_resetStation.Enabled = false;
            this.button_resetStation.Location = new System.Drawing.Point(9, 31);
            this.button_resetStation.Margin = new System.Windows.Forms.Padding(6);
            this.button_resetStation.Name = "button_resetStation";
            this.button_resetStation.Size = new System.Drawing.Size(91, 97);
            this.button_resetStation.TabIndex = 5;
            this.button_resetStation.Text = "Reset station";
            this.button_resetStation.UseVisualStyleBackColor = true;
            this.button_resetStation.Click += new System.EventHandler(this.button_resetStation_Click);
            // 
            // textBox_newStationNumber
            // 
            this.textBox_newStationNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_newStationNumber.Location = new System.Drawing.Point(229, 31);
            this.textBox_newStationNumber.MaxLength = 3;
            this.textBox_newStationNumber.Name = "textBox_newStationNumber";
            this.textBox_newStationNumber.Size = new System.Drawing.Size(174, 29);
            this.textBox_newStationNumber.TabIndex = 10;
            this.textBox_newStationNumber.Text = "0";
            this.textBox_newStationNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(109, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 24);
            this.label5.TabIndex = 10;
            this.label5.Text = "last check";
            // 
            // textBox_checkedChips
            // 
            this.textBox_checkedChips.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_checkedChips.Location = new System.Drawing.Point(258, 66);
            this.textBox_checkedChips.MaxLength = 5;
            this.textBox_checkedChips.Name = "textBox_checkedChips";
            this.textBox_checkedChips.Size = new System.Drawing.Size(145, 29);
            this.textBox_checkedChips.TabIndex = 10;
            this.textBox_checkedChips.Text = "0";
            this.textBox_checkedChips.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(109, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 24);
            this.label4.TabIndex = 10;
            this.label4.Text = "chips checked#";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "new station#";
            // 
            // textBox_lastCheck
            // 
            this.textBox_lastCheck.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_lastCheck.Location = new System.Drawing.Point(208, 101);
            this.textBox_lastCheck.MaxLength = 20;
            this.textBox_lastCheck.Name = "textBox_lastCheck";
            this.textBox_lastCheck.Size = new System.Drawing.Size(195, 29);
            this.textBox_lastCheck.TabIndex = 10;
            this.textBox_lastCheck.Text = "0000.00.00 00:00:00";
            this.textBox_lastCheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_getLastTeam
            // 
            this.button_getLastTeam.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_getLastTeam.Enabled = false;
            this.button_getLastTeam.Location = new System.Drawing.Point(119, 12);
            this.button_getLastTeam.Margin = new System.Windows.Forms.Padding(6);
            this.button_getLastTeam.Name = "button_getLastTeam";
            this.button_getLastTeam.Size = new System.Drawing.Size(130, 42);
            this.button_getLastTeam.TabIndex = 11;
            this.button_getLastTeam.Text = "Get last team";
            this.button_getLastTeam.UseVisualStyleBackColor = true;
            this.button_getLastTeam.Click += new System.EventHandler(this.button_getLastTeam_Click);
            // 
            // comboBox_mode
            // 
            this.comboBox_mode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_mode.FormattingEnabled = true;
            this.comboBox_mode.Items.AddRange(new object[] {
            "Init",
            "Start checkpoint",
            "Finish checkpoint"});
            this.comboBox_mode.Location = new System.Drawing.Point(119, 72);
            this.comboBox_mode.Name = "comboBox_mode";
            this.comboBox_mode.Size = new System.Drawing.Size(299, 32);
            this.comboBox_mode.TabIndex = 8;
            // 
            // checkBox_autoTime
            // 
            this.checkBox_autoTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_autoTime.AutoSize = true;
            this.checkBox_autoTime.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox_autoTime.Checked = true;
            this.checkBox_autoTime.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_autoTime.Location = new System.Drawing.Point(348, 128);
            this.checkBox_autoTime.Margin = new System.Windows.Forms.Padding(6);
            this.checkBox_autoTime.Name = "checkBox_autoTime";
            this.checkBox_autoTime.Size = new System.Drawing.Size(70, 28);
            this.checkBox_autoTime.TabIndex = 7;
            this.checkBox_autoTime.Text = " auto";
            this.checkBox_autoTime.UseVisualStyleBackColor = true;
            this.checkBox_autoTime.CheckedChanged += new System.EventHandler(this.checkBox_autoTime_CheckedChanged);
            // 
            // textBox_setTime
            // 
            this.textBox_setTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_setTime.Enabled = false;
            this.textBox_setTime.Location = new System.Drawing.Point(119, 126);
            this.textBox_setTime.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_setTime.MaxLength = 20;
            this.textBox_setTime.Name = "textBox_setTime";
            this.textBox_setTime.Size = new System.Drawing.Size(217, 29);
            this.textBox_setTime.TabIndex = 1;
            this.textBox_setTime.Text = "0000.00.00 00:00:00";
            this.textBox_setTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_setTime
            // 
            this.button_setTime.Enabled = false;
            this.button_setTime.Location = new System.Drawing.Point(6, 120);
            this.button_setTime.Margin = new System.Windows.Forms.Padding(6);
            this.button_setTime.Name = "button_setTime";
            this.button_setTime.Size = new System.Drawing.Size(101, 42);
            this.button_setTime.TabIndex = 0;
            this.button_setTime.Text = "Set time";
            this.button_setTime.UseVisualStyleBackColor = true;
            this.button_setTime.Click += new System.EventHandler(this.button_setTime_Click);
            // 
            // button_setMode
            // 
            this.button_setMode.Enabled = false;
            this.button_setMode.Location = new System.Drawing.Point(6, 66);
            this.button_setMode.Margin = new System.Windows.Forms.Padding(6);
            this.button_setMode.Name = "button_setMode";
            this.button_setMode.Size = new System.Drawing.Size(101, 42);
            this.button_setMode.TabIndex = 0;
            this.button_setMode.Text = "Set mode";
            this.button_setMode.UseVisualStyleBackColor = true;
            this.button_setMode.Click += new System.EventHandler(this.button_setMode_Click);
            // 
            // button_getStatus
            // 
            this.button_getStatus.Enabled = false;
            this.button_getStatus.Location = new System.Drawing.Point(6, 12);
            this.button_getStatus.Margin = new System.Windows.Forms.Padding(6);
            this.button_getStatus.Name = "button_getStatus";
            this.button_getStatus.Size = new System.Drawing.Size(101, 42);
            this.button_getStatus.TabIndex = 0;
            this.button_getStatus.Text = "Get status";
            this.button_getStatus.UseVisualStyleBackColor = true;
            this.button_getStatus.Click += new System.EventHandler(this.button_getStatus_Click);
            // 
            // tabPage_Chip
            // 
            this.tabPage_Chip.Controls.Add(this.label8);
            this.tabPage_Chip.Controls.Add(this.textBox_issueTime);
            this.tabPage_Chip.Controls.Add(this.textBox_records);
            this.tabPage_Chip.Controls.Add(this.button_updTeamMask);
            this.tabPage_Chip.Controls.Add(this.button_initChip);
            this.tabPage_Chip.Controls.Add(this.button_getChipsHistory);
            this.tabPage_Chip.Location = new System.Drawing.Point(4, 33);
            this.tabPage_Chip.Margin = new System.Windows.Forms.Padding(6);
            this.tabPage_Chip.Name = "tabPage_Chip";
            this.tabPage_Chip.Padding = new System.Windows.Forms.Padding(6);
            this.tabPage_Chip.Size = new System.Drawing.Size(433, 324);
            this.tabPage_Chip.TabIndex = 1;
            this.tabPage_Chip.Text = "Chip";
            this.tabPage_Chip.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(198, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 24);
            this.label8.TabIndex = 12;
            this.label8.Text = "issued";
            // 
            // textBox_issueTime
            // 
            this.textBox_issueTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_issueTime.Location = new System.Drawing.Point(272, 72);
            this.textBox_issueTime.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_issueTime.MaxLength = 20;
            this.textBox_issueTime.Name = "textBox_issueTime";
            this.textBox_issueTime.Size = new System.Drawing.Size(149, 29);
            this.textBox_issueTime.TabIndex = 3;
            this.textBox_issueTime.Text = "0000.00.00 00:00:00";
            this.textBox_issueTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_records
            // 
            this.textBox_records.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_records.Location = new System.Drawing.Point(272, 18);
            this.textBox_records.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_records.MaxLength = 11;
            this.textBox_records.Name = "textBox_records";
            this.textBox_records.Size = new System.Drawing.Size(149, 29);
            this.textBox_records.TabIndex = 2;
            this.textBox_records.Text = "00000-00000";
            this.textBox_records.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_updTeamMask
            // 
            this.button_updTeamMask.Enabled = false;
            this.button_updTeamMask.Location = new System.Drawing.Point(6, 66);
            this.button_updTeamMask.Margin = new System.Windows.Forms.Padding(6);
            this.button_updTeamMask.Name = "button_updTeamMask";
            this.button_updTeamMask.Size = new System.Drawing.Size(183, 42);
            this.button_updTeamMask.TabIndex = 0;
            this.button_updTeamMask.Text = "Update team mask";
            this.button_updTeamMask.UseVisualStyleBackColor = true;
            this.button_updTeamMask.Click += new System.EventHandler(this.button_updateTeamMask_Click);
            // 
            // button_getChipsHistory
            // 
            this.button_getChipsHistory.Enabled = false;
            this.button_getChipsHistory.Location = new System.Drawing.Point(6, 12);
            this.button_getChipsHistory.Margin = new System.Windows.Forms.Padding(6);
            this.button_getChipsHistory.Name = "button_getChipsHistory";
            this.button_getChipsHistory.Size = new System.Drawing.Size(183, 42);
            this.button_getChipsHistory.TabIndex = 0;
            this.button_getChipsHistory.Text = "Get records";
            this.button_getChipsHistory.UseVisualStyleBackColor = true;
            this.button_getChipsHistory.Click += new System.EventHandler(this.button_getChipHistory_Click);
            // 
            // button_initChip
            // 
            this.button_initChip.Enabled = false;
            this.button_initChip.Location = new System.Drawing.Point(6, 120);
            this.button_initChip.Margin = new System.Windows.Forms.Padding(6);
            this.button_initChip.Name = "button_initChip";
            this.button_initChip.Size = new System.Drawing.Size(183, 42);
            this.button_initChip.TabIndex = 0;
            this.button_initChip.Text = "Init chip";
            this.button_initChip.UseVisualStyleBackColor = true;
            this.button_initChip.Click += new System.EventHandler(this.button_initChip_Click);
            // 
            // tabPage_Raw
            // 
            this.tabPage_Raw.Controls.Add(this.comboBox_chipType);
            this.tabPage_Raw.Controls.Add(this.label13);
            this.tabPage_Raw.Controls.Add(this.label12);
            this.tabPage_Raw.Controls.Add(this.label11);
            this.tabPage_Raw.Controls.Add(this.label10);
            this.tabPage_Raw.Controls.Add(this.textBox_uid);
            this.tabPage_Raw.Controls.Add(this.textBox_data);
            this.tabPage_Raw.Controls.Add(this.textBox_readChipPage);
            this.tabPage_Raw.Controls.Add(this.textBox_writeChipPage);
            this.tabPage_Raw.Controls.Add(this.button_dumpChip);
            this.tabPage_Raw.Controls.Add(this.button_readChipPage);
            this.tabPage_Raw.Controls.Add(this.button_writeChipPage);
            this.tabPage_Raw.Location = new System.Drawing.Point(4, 33);
            this.tabPage_Raw.Name = "tabPage_Raw";
            this.tabPage_Raw.Size = new System.Drawing.Size(433, 324);
            this.tabPage_Raw.TabIndex = 2;
            this.tabPage_Raw.Text = "Raw";
            this.tabPage_Raw.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(135, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 24);
            this.label13.TabIndex = 17;
            this.label13.Text = "pages#";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(135, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 24);
            this.label12.TabIndex = 16;
            this.label12.Text = "data";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(135, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 24);
            this.label11.TabIndex = 15;
            this.label11.Text = "UID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(135, 78);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 24);
            this.label10.TabIndex = 14;
            this.label10.Text = "page#";
            // 
            // textBox_uid
            // 
            this.textBox_uid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_uid.Location = new System.Drawing.Point(207, 123);
            this.textBox_uid.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_uid.MaxLength = 24;
            this.textBox_uid.Name = "textBox_uid";
            this.textBox_uid.Size = new System.Drawing.Size(220, 29);
            this.textBox_uid.TabIndex = 8;
            this.textBox_uid.Tag = "0";
            this.textBox_uid.Text = "00 00 00 00 00 00 00 00 ";
            this.textBox_uid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_data
            // 
            this.textBox_data.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_data.Location = new System.Drawing.Point(207, 164);
            this.textBox_data.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_data.MaxLength = 12;
            this.textBox_data.Name = "textBox_data";
            this.textBox_data.Size = new System.Drawing.Size(220, 29);
            this.textBox_data.TabIndex = 7;
            this.textBox_data.Tag = "0";
            this.textBox_data.Text = "00 00 00 00";
            this.textBox_data.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_readChipPage
            // 
            this.textBox_readChipPage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_readChipPage.Location = new System.Drawing.Point(207, 21);
            this.textBox_readChipPage.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_readChipPage.MaxLength = 7;
            this.textBox_readChipPage.Name = "textBox_readChipPage";
            this.textBox_readChipPage.Size = new System.Drawing.Size(220, 29);
            this.textBox_readChipPage.TabIndex = 5;
            this.textBox_readChipPage.Tag = "0";
            this.textBox_readChipPage.Text = "000-000";
            this.textBox_readChipPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_writeChipPage
            // 
            this.textBox_writeChipPage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_writeChipPage.Location = new System.Drawing.Point(207, 75);
            this.textBox_writeChipPage.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_writeChipPage.MaxLength = 3;
            this.textBox_writeChipPage.Name = "textBox_writeChipPage";
            this.textBox_writeChipPage.Size = new System.Drawing.Size(220, 29);
            this.textBox_writeChipPage.TabIndex = 6;
            this.textBox_writeChipPage.Tag = "0";
            this.textBox_writeChipPage.Text = "0";
            this.textBox_writeChipPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button_readChipPage
            // 
            this.button_readChipPage.Enabled = false;
            this.button_readChipPage.Location = new System.Drawing.Point(6, 15);
            this.button_readChipPage.Margin = new System.Windows.Forms.Padding(6);
            this.button_readChipPage.Name = "button_readChipPage";
            this.button_readChipPage.Size = new System.Drawing.Size(120, 42);
            this.button_readChipPage.TabIndex = 3;
            this.button_readChipPage.Text = "Read chip";
            this.button_readChipPage.UseVisualStyleBackColor = true;
            this.button_readChipPage.Click += new System.EventHandler(this.button_readCardPage_Click);
            // 
            // button_writeChipPage
            // 
            this.button_writeChipPage.Enabled = false;
            this.button_writeChipPage.Location = new System.Drawing.Point(6, 69);
            this.button_writeChipPage.Margin = new System.Windows.Forms.Padding(6);
            this.button_writeChipPage.Name = "button_writeChipPage";
            this.button_writeChipPage.Size = new System.Drawing.Size(120, 42);
            this.button_writeChipPage.TabIndex = 4;
            this.button_writeChipPage.Text = "Write chip";
            this.button_writeChipPage.UseVisualStyleBackColor = true;
            this.button_writeChipPage.Click += new System.EventHandler(this.button_writeCardPage_Click);
            // 
            // textBox_teamMask
            // 
            this.textBox_teamMask.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_teamMask.Location = new System.Drawing.Point(219, 76);
            this.textBox_teamMask.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_teamMask.MaxLength = 16;
            this.textBox_teamMask.Name = "textBox_teamMask";
            this.textBox_teamMask.Size = new System.Drawing.Size(211, 29);
            this.textBox_teamMask.TabIndex = 2;
            this.textBox_teamMask.Tag = "0";
            this.textBox_teamMask.Text = "0000000000000000";
            this.textBox_teamMask.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Current station number";
            // 
            // textBox_stationNumber
            // 
            this.textBox_stationNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_stationNumber.Location = new System.Drawing.Point(219, 3);
            this.textBox_stationNumber.MaxLength = 3;
            this.textBox_stationNumber.Name = "textBox_stationNumber";
            this.textBox_stationNumber.Size = new System.Drawing.Size(211, 29);
            this.textBox_stationNumber.TabIndex = 9;
            this.textBox_stationNumber.Text = "000";
            this.textBox_stationNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_terminal
            // 
            this.textBox_terminal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_terminal.HideSelection = false;
            this.textBox_terminal.Location = new System.Drawing.Point(3, 3);
            this.textBox_terminal.Margin = new System.Windows.Forms.Padding(6);
            this.textBox_terminal.MaxLength = 3276700;
            this.textBox_terminal.Multiline = true;
            this.textBox_terminal.Name = "textBox_terminal";
            this.textBox_terminal.ReadOnly = true;
            this.textBox_terminal.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_terminal.Size = new System.Drawing.Size(351, 381);
            this.textBox_terminal.TabIndex = 1;
            this.textBox_terminal.TextChanged += new System.EventHandler(this.textBox_terminal_TextChanged);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 57600;
            this.serialPort1.ErrorReceived += new System.IO.Ports.SerialErrorReceivedEventHandler(this.serialPort1_ErrorReceived);
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Title = "Save log to file...";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // comboBox_portName
            // 
            this.comboBox_portName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_portName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_portName.FormattingEnabled = true;
            this.comboBox_portName.Location = new System.Drawing.Point(85, 481);
            this.comboBox_portName.Margin = new System.Windows.Forms.Padding(6);
            this.comboBox_portName.Name = "comboBox_portName";
            this.comboBox_portName.Size = new System.Drawing.Size(286, 32);
            this.comboBox_portName.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 484);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Port #";
            // 
            // button_openPort
            // 
            this.button_openPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_openPort.Location = new System.Drawing.Point(382, 475);
            this.button_openPort.Margin = new System.Windows.Forms.Padding(6);
            this.button_openPort.Name = "button_openPort";
            this.button_openPort.Size = new System.Drawing.Size(133, 42);
            this.button_openPort.TabIndex = 5;
            this.button_openPort.Text = "Open port";
            this.button_openPort.UseVisualStyleBackColor = true;
            this.button_openPort.Click += new System.EventHandler(this.button_openPort_Click);
            // 
            // button_clear
            // 
            this.button_clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_clear.Location = new System.Drawing.Point(6, 393);
            this.button_clear.Margin = new System.Windows.Forms.Padding(6);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(100, 32);
            this.button_clear.TabIndex = 6;
            this.button_clear.Text = "Clear log";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_closePort
            // 
            this.button_closePort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_closePort.Enabled = false;
            this.button_closePort.Location = new System.Drawing.Point(666, 475);
            this.button_closePort.Margin = new System.Windows.Forms.Padding(6);
            this.button_closePort.Name = "button_closePort";
            this.button_closePort.Size = new System.Drawing.Size(133, 42);
            this.button_closePort.TabIndex = 4;
            this.button_closePort.Text = "Close port";
            this.button_closePort.UseVisualStyleBackColor = true;
            this.button_closePort.Click += new System.EventHandler(this.button_closePort_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(247, 393);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 32);
            this.button1.TabIndex = 7;
            this.button1.Text = "Save log";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button_saveFile_Click);
            // 
            // checkBox_autoScroll
            // 
            this.checkBox_autoScroll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox_autoScroll.AutoSize = true;
            this.checkBox_autoScroll.Checked = true;
            this.checkBox_autoScroll.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_autoScroll.Location = new System.Drawing.Point(118, 407);
            this.checkBox_autoScroll.Margin = new System.Windows.Forms.Padding(6);
            this.checkBox_autoScroll.Name = "checkBox_autoScroll";
            this.checkBox_autoScroll.Size = new System.Drawing.Size(112, 28);
            this.checkBox_autoScroll.TabIndex = 8;
            this.checkBox_autoScroll.Text = "Autoscroll";
            this.checkBox_autoScroll.UseVisualStyleBackColor = true;
            // 
            // button_refresh
            // 
            this.button_refresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_refresh.Location = new System.Drawing.Point(524, 475);
            this.button_refresh.Name = "button_refresh";
            this.button_refresh.Size = new System.Drawing.Size(133, 42);
            this.button_refresh.TabIndex = 10;
            this.button_refresh.Text = "Refresh";
            this.button_refresh.UseVisualStyleBackColor = true;
            this.button_refresh.Click += new System.EventHandler(this.button_refresh_Click);
            // 
            // checkBox_portMon
            // 
            this.checkBox_portMon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox_portMon.AutoSize = true;
            this.checkBox_portMon.Checked = true;
            this.checkBox_portMon.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_portMon.Location = new System.Drawing.Point(118, 384);
            this.checkBox_portMon.Margin = new System.Windows.Forms.Padding(6);
            this.checkBox_portMon.Name = "checkBox_portMon";
            this.checkBox_portMon.Size = new System.Drawing.Size(130, 28);
            this.checkBox_portMon.TabIndex = 9;
            this.checkBox_portMon.Text = "Port monitor";
            this.checkBox_portMon.UseVisualStyleBackColor = true;
            // 
            // textBox_commandNumber
            // 
            this.textBox_commandNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_commandNumber.Location = new System.Drawing.Point(219, 38);
            this.textBox_commandNumber.MaxLength = 5;
            this.textBox_commandNumber.Name = "textBox_commandNumber";
            this.textBox_commandNumber.Size = new System.Drawing.Size(211, 29);
            this.textBox_commandNumber.TabIndex = 9;
            this.textBox_commandNumber.Text = "00000";
            this.textBox_commandNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(169, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "Command number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 24);
            this.label7.TabIndex = 11;
            this.label7.Text = "Team mask";
            // 
            // dataGridView_teams
            // 
            this.dataGridView_teams.AllowUserToAddRows = false;
            this.dataGridView_teams.AllowUserToDeleteRows = false;
            this.dataGridView_teams.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView_teams.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridView_teams.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_teams.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.team,
            this.time,
            this.TeamMask});
            this.dataGridView_teams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_teams.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView_teams.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_teams.Name = "dataGridView_teams";
            this.dataGridView_teams.RowHeadersVisible = false;
            this.dataGridView_teams.Size = new System.Drawing.Size(350, 425);
            this.dataGridView_teams.TabIndex = 12;
            // 
            // tabControl_teamData
            // 
            this.tabControl_teamData.Controls.Add(this.tabPage_terminal);
            this.tabControl_teamData.Controls.Add(this.tabPage_grid);
            this.tabControl_teamData.Controls.Add(this.tabPage_chipContent);
            this.tabControl_teamData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_teamData.Location = new System.Drawing.Point(0, 0);
            this.tabControl_teamData.Name = "tabControl_teamData";
            this.tabControl_teamData.SelectedIndex = 0;
            this.tabControl_teamData.Size = new System.Drawing.Size(364, 468);
            this.tabControl_teamData.TabIndex = 13;
            // 
            // tabPage_terminal
            // 
            this.tabPage_terminal.Controls.Add(this.textBox_terminal);
            this.tabPage_terminal.Controls.Add(this.button1);
            this.tabPage_terminal.Controls.Add(this.checkBox_portMon);
            this.tabPage_terminal.Controls.Add(this.checkBox_autoScroll);
            this.tabPage_terminal.Controls.Add(this.button_clear);
            this.tabPage_terminal.Location = new System.Drawing.Point(4, 33);
            this.tabPage_terminal.Name = "tabPage_terminal";
            this.tabPage_terminal.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_terminal.Size = new System.Drawing.Size(356, 431);
            this.tabPage_terminal.TabIndex = 0;
            this.tabPage_terminal.Text = "Terminal";
            this.tabPage_terminal.UseVisualStyleBackColor = true;
            // 
            // tabPage_grid
            // 
            this.tabPage_grid.Controls.Add(this.dataGridView_teams);
            this.tabPage_grid.Location = new System.Drawing.Point(4, 33);
            this.tabPage_grid.Name = "tabPage_grid";
            this.tabPage_grid.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_grid.Size = new System.Drawing.Size(356, 431);
            this.tabPage_grid.TabIndex = 1;
            this.tabPage_grid.Text = "Grid";
            this.tabPage_grid.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Location = new System.Drawing.Point(1, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.AutoScroll = true;
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_commandNumber);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_stationNumber);
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_teamMask);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.tabControl);
            this.splitContainer1.Panel1MinSize = 440;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.Controls.Add(this.tabControl_teamData);
            this.splitContainer1.Panel2MinSize = 360;
            this.splitContainer1.Size = new System.Drawing.Size(812, 472);
            this.splitContainer1.SplitterDistance = 440;
            this.splitContainer1.TabIndex = 14;
            // 
            // tabPage_chipContent
            // 
            this.tabPage_chipContent.Controls.Add(this.dataGridView_rawData);
            this.tabPage_chipContent.Location = new System.Drawing.Point(4, 33);
            this.tabPage_chipContent.Name = "tabPage_chipContent";
            this.tabPage_chipContent.Size = new System.Drawing.Size(356, 431);
            this.tabPage_chipContent.TabIndex = 2;
            this.tabPage_chipContent.Text = "Chip Content";
            this.tabPage_chipContent.UseVisualStyleBackColor = true;
            // 
            // button_dumpChip
            // 
            this.button_dumpChip.Enabled = false;
            this.button_dumpChip.Location = new System.Drawing.Point(6, 196);
            this.button_dumpChip.Margin = new System.Windows.Forms.Padding(6);
            this.button_dumpChip.Name = "button_dumpChip";
            this.button_dumpChip.Size = new System.Drawing.Size(120, 42);
            this.button_dumpChip.TabIndex = 3;
            this.button_dumpChip.Text = "Dump chip";
            this.button_dumpChip.UseVisualStyleBackColor = true;
            this.button_dumpChip.Click += new System.EventHandler(this.button_dumpChip_Click);
            // 
            // comboBox_chipType
            // 
            this.comboBox_chipType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_chipType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_chipType.FormattingEnabled = true;
            this.comboBox_chipType.Items.AddRange(new object[] {
            "Ntag213",
            "Ntag215",
            "Ntag216"});
            this.comboBox_chipType.Location = new System.Drawing.Point(139, 202);
            this.comboBox_chipType.Name = "comboBox_chipType";
            this.comboBox_chipType.Size = new System.Drawing.Size(288, 32);
            this.comboBox_chipType.TabIndex = 18;
            this.comboBox_chipType.SelectedIndexChanged += new System.EventHandler(this.comboBox_chipType_SelectedIndexChanged);
            // 
            // dataGridView_rawData
            // 
            this.dataGridView_rawData.AllowUserToAddRows = false;
            this.dataGridView_rawData.AllowUserToDeleteRows = false;
            this.dataGridView_rawData.AllowUserToResizeColumns = false;
            this.dataGridView_rawData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView_rawData.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView_rawData.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridView_rawData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_rawData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Page,
            this.Data,
            this.decoded});
            this.dataGridView_rawData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_rawData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView_rawData.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_rawData.Name = "dataGridView_rawData";
            this.dataGridView_rawData.ReadOnly = true;
            this.dataGridView_rawData.RowHeadersVisible = false;
            this.dataGridView_rawData.Size = new System.Drawing.Size(356, 431);
            this.dataGridView_rawData.TabIndex = 0;
            // 
            // Page
            // 
            this.Page.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Page.HeaderText = "Page#";
            this.Page.MaxInputLength = 100;
            this.Page.Name = "Page";
            this.Page.ReadOnly = true;
            this.Page.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Page.Width = 70;
            // 
            // Data
            // 
            this.Data.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Data.HeaderText = "Data";
            this.Data.MaxInputLength = 16;
            this.Data.Name = "Data";
            this.Data.ReadOnly = true;
            this.Data.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Data.Width = 53;
            // 
            // decoded
            // 
            this.decoded.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.decoded.HeaderText = "DecodedData";
            this.decoded.Name = "decoded";
            this.decoded.ReadOnly = true;
            this.decoded.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.decoded.Width = 131;
            // 
            // team
            // 
            this.team.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.team.HeaderText = "Team#";
            this.team.Name = "team";
            this.team.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.team.Width = 75;
            // 
            // time
            // 
            this.time.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.time.HeaderText = "CheckInTime";
            this.time.Name = "time";
            this.time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.time.Width = 128;
            // 
            // TeamMask
            // 
            this.TeamMask.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.TeamMask.HeaderText = "Column1";
            this.TeamMask.Name = "TeamMask";
            this.TeamMask.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TeamMask.Width = 92;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 532);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.button_refresh);
            this.Controls.Add(this.button_openPort);
            this.Controls.Add(this.button_closePort);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_portName);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MinimumSize = new System.Drawing.Size(830, 570);
            this.Name = "Form1";
            this.Text = "RFID Station control";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage_Station.ResumeLayout(false);
            this.tabPage_Station.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage_Chip.ResumeLayout(false);
            this.tabPage_Chip.PerformLayout();
            this.tabPage_Raw.ResumeLayout(false);
            this.tabPage_Raw.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_teams)).EndInit();
            this.tabControl_teamData.ResumeLayout(false);
            this.tabPage_terminal.ResumeLayout(false);
            this.tabPage_terminal.PerformLayout();
            this.tabPage_grid.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabPage_chipContent.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_rawData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage_Station;
        private System.Windows.Forms.TextBox textBox_setTime;
        private System.Windows.Forms.Button button_setTime;
        private System.Windows.Forms.Button button_setMode;
        private System.Windows.Forms.TabPage tabPage_Chip;
        private System.Windows.Forms.Button button_updTeamMask;
        private System.Windows.Forms.Button button_getChipsHistory;
        private System.Windows.Forms.Button button_initChip;
        private System.Windows.Forms.Button button_getStatus;
        private System.Windows.Forms.TextBox textBox_terminal;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ComboBox comboBox_portName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_openPort;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TextBox textBox_teamMask;
        private System.Windows.Forms.TextBox textBox_records;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_closePort;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_resetStation;
        private System.Windows.Forms.CheckBox checkBox_autoTime;
        private System.Windows.Forms.CheckBox checkBox_autoScroll;
        private System.Windows.Forms.Button button_refresh;
        private System.Windows.Forms.ComboBox comboBox_mode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_stationNumber;
        private System.Windows.Forms.CheckBox checkBox_portMon;
        private System.Windows.Forms.TextBox textBox_commandNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_lastCheck;
        private System.Windows.Forms.TextBox textBox_checkedChips;
        private System.Windows.Forms.TextBox textBox_newStationNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_issueTime;
        private System.Windows.Forms.Button button_getLastTeam;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage_Raw;
        private System.Windows.Forms.TextBox textBox_readChipPage;
        private System.Windows.Forms.TextBox textBox_writeChipPage;
        private System.Windows.Forms.Button button_readChipPage;
        private System.Windows.Forms.Button button_writeChipPage;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_uid;
        private System.Windows.Forms.TextBox textBox_data;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView_teams;
        private System.Windows.Forms.TabControl tabControl_teamData;
        private System.Windows.Forms.TabPage tabPage_terminal;
        private System.Windows.Forms.TabPage tabPage_grid;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ComboBox comboBox_chipType;
        private System.Windows.Forms.Button button_dumpChip;
        private System.Windows.Forms.TabPage tabPage_chipContent;
        private System.Windows.Forms.DataGridView dataGridView_rawData;
        private System.Windows.Forms.DataGridViewTextBoxColumn Page;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data;
        private System.Windows.Forms.DataGridViewTextBoxColumn decoded;
        private System.Windows.Forms.DataGridViewTextBoxColumn team;
        private System.Windows.Forms.DataGridViewTextBoxColumn time;
        private System.Windows.Forms.DataGridViewTextBoxColumn TeamMask;
    }
}

